'use strict';

module.exports = function () {

    return {

        options: {
            context: {
                DEBUG: true
            }
        },
        app: {
            src: 'app/index.template.html',
            dest: 'app/index.html'
        },
        dist: {
            src: 'app/index.template.html',
            dest: 'dist/index.html'
        }
    };
};
