'use strict';

module.exports = function() {
    return {
        options: {
            dirs: ['dist']
        },
        html: 'dist/index.html'
    };
};