'use strict';

module.exports = function () {

    // Put files not handled in other tasks here
    return {

        dist: {
            files: [{
                expand: true,
                dot: true,
                dest: 'dist',
                cwd: 'app',
                src: [
                    'views/**/*',
                    'assets/**/*'
                ]
            }]
        }
    };
};
