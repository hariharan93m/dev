'use strict';

module.exports = function() {
    return {
        replace: {
            files: ['app/index.template.html'],
            tasks: ['preprocess:app']
        }
    };
};
