'use strict';

module.exports = function() {

    var defaultPatterns = [{
        json: {
            pkg: '<%= pkg %>',
            dateAsMillisecondsSince1970: '<%= new Date().getTime() %>'
        }
    }];

    return {
        options: {
            patterns: defaultPatterns
        },
        app: {
            files: [{
                expand: true,
                flatten: true,
                src: ['app/index.html'],
                dest: 'app/'
            }]
        },
        dist: {
            src: 'dist/index.html',
            dest: 'dist/index.html'
        }
    };
};
