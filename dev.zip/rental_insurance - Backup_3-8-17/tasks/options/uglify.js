'use strict';

module.exports = function() {
    return {
        options: {
            compress: false,   //compress the code
            mangle: false,      //prevent changes to your variable and function names
            sourceMapIncludeSources: true,  //to include the content of source files in the source map as sourcesContent property
            sourceMap: true,     //to generate sourceMap for the minified file
        }
      // useminPrepare takes care of the rest of this config
    };
};
