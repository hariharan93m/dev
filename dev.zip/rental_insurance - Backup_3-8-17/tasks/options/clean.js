'use strict';

module.exports = function() {
    return {
        app  : 'app/index.html',
        dist : 'dist'
   };
};
