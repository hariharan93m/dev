var app = angular.module('guestCheckoutApp', ['ui.router']);

app.config(['$stateProvider', '$urlRouterProvider', '$locationProvider',function($stateProvider, $urlRouterProvider, $locationProvider) {
  $urlRouterProvider.otherwise('/tenant-insurance');

  $stateProvider
  .state('tenant-insurance', {
      url: '/tenant-insurance',
      templateUrl:'views/steps/rental-insurance.html'
  })
  .state('place-order', {
      url: '/place-order',
      templateUrl:'views/steps/rental-insurance.html',
      controller: function($scope) {
          $scope.placeOrder.error = true;
      },
      params : {
          blc_cid: ''
      },
      data:{
          title:'Rental Insurance Valuation'
      }
   })
   .state('not-available', {
       url: '/not-available',
       templateUrl:'views/steps/not-available.html'
   })
  .state('confirmation', {
      url: '/confirmation',
      templateUrl:'views/steps/order-confirmation.html',
      controller:'',
      params: {
          custId: '',
          orderId: ''
      },
      data:{
      }
  });

  $locationProvider.html5Mode({
      enabled: true,
      requireBase: false
  });

}]);

app.run(function($rootScope) {

  $rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
    //$rootScope.stateData = ($(".renters-insurance-header").text()).trim();
  });
});
