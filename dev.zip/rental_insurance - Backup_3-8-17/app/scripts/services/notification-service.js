app.service('notifyService', function ($http) {

    this.info = function (message, timeout) {
        notify(message, 'info');
    };

    this.error = function (message, timeout) {
        notify(message, 'danger');
    };

    this.success = function (message, timeout) {
        notify(message, 'success');
    };

    function notify(message, type, timeout) {
        if (!message) {
            return;
        }

        timeout = timeout || 5000;
        type    = type || 'info';

        $.bootstrapGrowl(message, {
          ele: 'html', // which element to append to
          type: type, // (null, 'info', 'danger', 'success')
          offset: {from: 'top', amount: 20}, // 'top', or 'bottom'
          align: 'center', // ('left', 'right', or 'center')
          width: 'auto', // (integer, or 'auto')
          delay: timeout, // Time while the message will be displayed. It's not equivalent to the *demo* timeOut!
          allow_dismiss: true, // If true then will display a cross to close the popup.
          stackup_spacing: 10 // spacing between consecutively stacked growls.
        });
    }

});
