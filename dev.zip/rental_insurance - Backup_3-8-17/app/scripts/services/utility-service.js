app.service('utilityService',['$http', '$timeout', function ($http, $timeout) {

    var customerId = '',
        OrderId='';

        // setter / getter array of customer id if the logged in user is Loan Manager
        // or single customer id if the logged in user is Loan Officer
        this.setCustomerId = function (id) {
            customerId = id;
        };

        this.getCustomerId = function () {
            return customerId;
        };

        this.setOrderId = function (id) {
            return OrderId = id;
        };

        this.getOrderId = function () {
            return OrderId;
        };

        this.redirect = function (delay) {
            if (delay) {
                $timeout(function (argument) {
                    window.location.href = '/';
                }, delay);
                return;
            }
            window.location.href = '/';
        };

    }]);
