app.service('customerService',['$http', function ($http) {

    this.getCustomerId = function (custObj) {
        return $http({
            method: 'GET',
            url: '/customer/enhanced?username='+custObj.emailAddress,
            headers:{
                'Content-Type':'application/json'
            },
            data:{}
        }).then(function (response) {
            if (response.data && response.data.id) {
                 return response.data.id;
            }
        }, function (error) {
            // console.log('Error: Customer Not Found!');

            if (error.status !== 404) {
                return;
            }
            // if not exists, register customer and get cust id
            var userInfoPayload = angular.extend(custObj, {
                'password'       : 'password',
                'passwordConfirm': 'password',
                'sendEmail'      : 'false'
             });

             return $http({
                 method: 'POST',
                 url: '/customer/enhanced/register',
                 headers:{
                     'Content-Type':'application/json'
                 }, data: userInfoPayload
             }).then(function success(response) {
                 if (response.data && response.data.id) {
                      return response.data.id;
                 }
             }, function (error) {
                //  console.log('Error: Cannot create customer!');
                 return error;
             });
        });
    };

    this.createCart = function (customerId) {
        return $http({
            method: 'POST',
            url: '/cart/?customerId='+customerId,
            headers:{
                'Content-Type':'application/json'
            },
            data:{}
        }).then(function (response) {
            if (response.data && response.data.customer) {
                return response.data.customer.id;
            }
        }, function (error) {
            // console.log('Cannot create cart');
            return error;
        });
    };

    this.deletCartItem = function (customerId, orderItemId) {
        return $http({
            method: 'DELETE',
            url: '/cart/items/'+orderItemId+'?customerId='+customerId,
            headers:{
                'Content-Type':'application/json'
            },
            data:{}
        }).then(function (response) {

        }, function (error) {
            // console.log('Delete cart failed');
            return error;
        });
    };

    this.getCart = function (customerId) {
        return $http({
            method: 'GET',
            url: '/cart?customerId='+customerId,
            headers:{
                'Content-Type':'application/json'
            },
            data:{}
        });
    };

    this.getDynamicProduct = function () {
        return $http({
            method: 'GET',
            url: '../resources/product-description.json',
            headers:{
                'Content-Type':'application/json'
            },
            data:{}
        });
    };

    this.getFullfilment  = function (customerId) {
        return $http({
            method: 'GET',
            url: '/cart/enhanced/all?customerId='+customerId,
            headers:{
                'Content-Type':'application/json'
            },
            data:{}
        });
    };

}]);
