'use strict';

app.service('valuationService',['$http', function ($http, $httpBackend) {
    var estimation = {};

        this.productValues = function(categoryId) {
            return  $http({
                        method: 'GET',
                        url: '/catalog/category/'+categoryId,
                        headers:{
                            'Content-Type':'application/json'
                        },
                        data:{}
                    })
                    .success(function (data, status, headerValues, config){

                        })
                    .error(function (error) {

                        });
        };

        this.getParentCategoryValues = function() {
            return  $http({
                        method: 'GET',
                        url: '/catalog/categories/parents?productLimit=0&productOffset=0&subcategoryLimit=0&subcategoryOffset=0',
                        headers:{
                            'Content-Type':'application/json'
                        },
                        data:{}
                    })
                    .success(function (data, status, headerValues, config){

                        })
                    .error(function (error) {

                        });

        };

        this.getMasterPolicy = function (clientId, siteName, productName) {
            return  $http({
                        method: 'GET',
                        url: '/catalog/enhanced/find/key/'+clientId+'?siteName='+siteName+'&productName='+productName,
                        headers:{
                            'Content-Type':'application/json'
                        },
                        data:{}
                    })
                    .success(function (data, status, headerValues, config){

                        })
                    .error(function (error) {

                        });
        };


    }]);
