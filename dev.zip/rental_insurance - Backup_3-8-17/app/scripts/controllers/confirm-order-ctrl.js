app.controller('ConfirmOrderCtrl' ,
    ['$scope',
    '$http',
    'notifyService',
    'utilityService',
    '$location',
    'valuationService',
    'customerService',
    '$window',
    function($scope, $http, notifyService, utilityService, $location, valuationService, customerService, $window) {
        $scope.queryParamValues = $location.search();

        $scope.homeLayout = {};
        $scope.isLoading = true;

        var host = $location.host();
        if (host.indexOf('ses') === 0) {
            $scope.siteName = 'ses';
            $scope.siteIdentifier.value = 'ses';
            $('head').append('<script type="text/javascript" src="assets/js/ses-gtm-one.js"></script>');
            $('head').append('<script type="text/javascript" src="assets/js/ses-gtm-two.js"></script>');
        } else {
            $scope.siteIdentifier.value = 'rhss';
            $('head').append('<script type="text/javascript" src="assets/js/rhss-gtm-one.js"></script>');
            $('head').append('<script type="text/javascript" src="assets/js/rhss-gtm-two.js"></script>');
        }

        $scope.nextTab = function (tabUrl) {
            $scope.currentTab = tabUrl;
        };

        if (!$scope.queryParamValues.blc_cid && !$scope.queryParamValues.blc_oid) {
            //if not cust id or order id not found, move to the root
            utilityService.redirect();
            return;
        }

        var custId = Number($scope.queryParamValues.blc_cid),
            orderId = Number($scope.queryParamValues.blc_oid);

        if (isNaN(custId) && isNaN(orderId)) {
            utilityService.redirect();
            return;
        }

        $scope.homeConfirmation = {};
        $scope.queryParamValues.x_account_number = 'XXXX-XXXX-XXXX-' + $scope.queryParamValues.x_account_number.substr(4, 8);

        valuationService.getParentCategoryValues().then(function (dataValue) {
            var dynamicCategory = {};

            customerService.getDynamicProduct().then(function (response) {
                $window.document.title = "Purchase " +response.data.mainHeader;
                dynamicCategory.name = response.data.categoryName;
                dynamicCategory.ProductName = response.data.productName;

                dynamicCategory.policyOptionWithBoolean = response.data.policyOptionWithBoolean;
                var poSplit = dynamicCategory.policyOptionWithBoolean.split('.');
                $scope.policyOptionWithBoolean.value = poSplit[1];
                dynamicCategory.policyOptionWithSelect = response.data.policyOptionWithSelect;
                var poSplit = dynamicCategory.policyOptionWithSelect.split('.');
                $scope.policyOptionWithSelect.value = poSplit[1];

                $scope.dynamicTags.mainHeader = response.data.mainHeader;
                $window.document.title = "Purchase " +response.data.mainHeader;
                $scope.dynamicTags.bottomNote = response.data.bottomNote;
                $scope.dynamicTags.descriptionOne = response.data.descriptionOne;
                $scope.dynamicTags.descriptionTwo = response.data.descriptionTwo;
                $scope.dynamicTags.faqLink = response.data.faqLink;
                $scope.dynamicTags.faqName = response.data.faqName;
                $scope.dynamicTags.headerTwo = response.data.headerTwo;
                $scope.dynamicTags.howMuchPopUp = response.data.howMuchPopUp;
                $scope.dynamicTags.offeredBy = response.data.offeredBy;
                $scope.dynamicTags.siteUrl = response.data.siteUrl;
                $scope.dynamicTags.whatDoesPopup = response.data.whatDoesPopup;
                $scope.dynamicTags.fbUrl = response.data.fbUrl;
                $scope.dynamicTags.gPlusUrl = response.data.gPlusUrl;
                $scope.dynamicTags.youtubeUrl = response.data.youtubeUrl;
                $scope.dynamicTags.termsOfUse = response.data.termsOfUse;
                $scope.dynamicTags.privacyPolicy = response.data.privacyPolicy;
                $scope.dynamicTags.contactNumber = response.data.contactNumber;
                $scope.dynamicTags.contactAddress = response.data.contactAddress;
                $scope.dynamicTags.tagLine = response.data.tagLine;
                $scope.dynamicTags.confirmationDescriptionOne = response.data.confirmationDescriptionOne;
                $scope.dynamicTags.confirmationDescriptionTwo = response.data.confirmationDescriptionTwo;
                $scope.dynamicTags.confirmationDescriptionThree = response.data.confirmationDescriptionThree;
                $scope.dynamicTags.confirmationDescriptionFour = response.data.confirmationDescriptionFour;
                $scope.dynamicTags.returnHomeButton = response.data.returnHomeButton;


                var category = _.find(dataValue.data.category, {name: dynamicCategory.name});
                categoryId = category.id;
                $scope.categoryId = categoryId;
                valuationService.productValues(categoryId).then(function (dataValue) {
                    var product = dataValue.data;
                    var stateValue = [];
                    var coverageValue = [];
                    var annualPremium = [];
                    //var order = '';
                    var fullfilmentData = '';

                    var product = _.find(dataValue.data.product, {name: dynamicCategory.ProductName });
                    $scope.ProductName = product.name;
                    var freeValuation = _.each(product.productOption, function(allowedValue){});
                    $scope.retailPrice = product.retailPrice.amount;

                    customerService.getFullfilment(custId).then(function (response) {
                        fullfilmentData = response.data;

                    var order = _.find(fullfilmentData, {id: orderId});
                    $scope.orderNumber = order.orderNumber;
                    var personalPropertyPolicy = _.find(order.orderItem[0].orderItemAttribute, {name: $scope.policyOptionWithSelect.value });
                    var dogBiteCoveragePolicy = _.find(order.orderItem[0].orderItemAttribute, {name: $scope.policyOptionWithBoolean.value });
                    $scope.personalProperty = personalPropertyPolicy.value;
                    $scope.dogBiteCoverage = dogBiteCoveragePolicy.value;

                    var dogBiteCoverageValues = _.find(freeValuation, {attributeName: dynamicCategory.policyOptionWithBoolean});
                    $scope.dogBiteCoverageLabel = dogBiteCoverageValues.label;
                    var dogBiteCoverage = _.find(dogBiteCoverageValues.allowedValue, {attributeValue:$scope.dogBiteCoverage });
                    $scope.dogBiteCoverageValue = dogBiteCoverage.priceAdjustment.amount;


                    var personalCoverageValues = _.find(freeValuation,{attributeName: dynamicCategory.policyOptionWithSelect});
                    $scope.personalCoverageLabel = personalCoverageValues.label;
                    var personalCoverage = _.find(personalCoverageValues.allowedValue, {attributeValue:$scope.personalProperty });
                    $scope.personalCoverageValue = personalCoverage.priceAdjustment.amount;

                    var addressValues = _.find(order.orderItem[0].orderItemAttribute,{name:'address'});
                    $scope.rentalAddress = JSON.parse(addressValues.value);

                    });
                });
            });
        });
}]);
