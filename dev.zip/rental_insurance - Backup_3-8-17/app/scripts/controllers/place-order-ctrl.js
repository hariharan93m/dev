app.controller('PlaceOrderCtrl',
    ['$scope',
     '$filter',
     '$http',
     '$state',
     'utilityService',
     'valuationService',
     '$stateParams',
     'notifyService',
     'customerService',
     '$location',
     '$timeout',
     function($scope, $filter, $http, $state, utilityService, valuationService, $stateParams, notifyService, customerService, $location, $timeout) {
        $scope.queryParamValues = $location.search();
        $scope.isLoading = true;
        var custId = $scope.custId;
        if($scope.custId) {
          $stateParams.blc_cid = $scope.custId;
      } else {
          $scope.houseLayout.street_add1 = $scope.queryParamValues.x_address;
          $scope.houseLayout.city = $scope.queryParamValues.x_city;
          $scope.houseLayout.state = $scope.queryParamValues.x_state;
          $scope.houseLayout.zip = $scope.queryParamValues.x_zip;
          $scope.houseLayout.firstName = $scope.queryParamValues.x_first_name;
          $scope.houseLayout.lastName = $scope.queryParamValues.x_last_name;

          var host = $location.host();
          $scope.siteName = host.split('-')[0];

          customerService.getDynamicProduct().then(function (response) {

              dynamicCategory.name = response.data.categoryName;
              $scope.dynamicTags.productName = response.data.productName;
              dynamicCategory.policyOptionWithBoolean = response.data.policyOptionWithBoolean;
              var poSplit = dynamicCategory.policyOptionWithBoolean.split('.');
              $scope.policyOptionWithBoolean.value = poSplit[1];

              dynamicCategory.policyOptionWithSelect = response.data.policyOptionWithSelect;
              var poSplit = dynamicCategory.policyOptionWithSelect.split('.');
              $scope.policyOptionWithSelect.value = poSplit[1];

              $scope.optionalProductOption = response.data.optionalProductOption;

              $scope.dynamicTags.mainHeader = response.data.mainHeader;
              $window.document.title = "Purchase " +response.data.mainHeader;
              $scope.dynamicTags.bottomNote = response.data.bottomNote;
              $scope.dynamicTags.descriptionOne = response.data.descriptionOne;
              $scope.dynamicTags.descriptionTwo = response.data.descriptionTwo;
              $scope.dynamicTags.faqLink = response.data.faqLink;
              $scope.dynamicTags.faqName = response.data.faqName;
              $scope.dynamicTags.headerTwo = response.data.headerTwo;
              $scope.dynamicTags.howMuchPopUp = response.data.howMuchPopUp;
              $scope.dynamicTags.offeredBy = response.data.offeredBy;
              $scope.dynamicTags.siteUrl = response.data.siteUrl;
              $scope.dynamicTags.whatDoesPopup = response.data.whatDoesPopup;
              $scope.dynamicTags.gPlusUrl = response.data.gPlusUrl;
              $scope.dynamicTags.youtubeUrl = response.data.youtubeUrl;
              $scope.dynamicTags.termsOfUse = response.data.termsOfUse;
              $scope.dynamicTags.privacyPolicy = response.data.privacyPolicy;
              $scope.dynamicTags.contactNumber = response.data.contactNumber;
              $scope.dynamicTags.contactAddress = response.data.contactAddress;
              $scope.dynamicTags.faqText = response.data.faqText;
              $scope.dynamicTags.tagLine = response.data.tagLine;
          });

          $location.search({});
      }
        $scope.$on('buyEvent', function(e) {
            $scope.placeOrder();
        });

        $scope.creditCardValidate = function(value) {
            if(value) {
              if(value.length > 0) {
              var reg = new RegExp("^[0-9]{16}$");
              $scope.validation.cardNumber = true;
              if(reg.test(value)) {
                $(".form-cardNumber").css("border-bottom", "2px solid #62e69a");
                $scope.validation.cardNumber = false;
              } else {
                $(".form-cardNumber").css("border-bottom", "2px solid #d83e3b");
              }
              }
            } else {
              $(".form-cardNumber").css("border-bottom", "2px solid #d83e3b");
              $scope.validation.cardNumber = true;
            }
        };

        $scope.expMonthValidate = function(value) {
          if(value) {
            if(value.length > 0) {
            var reg = new RegExp("^[0-9]{2}$");
            $scope.validation.expMonth = true;
            if(reg.test(value)) {
              $(".exp-month").css("border-bottom", "2px solid #62e69a");
              $scope.validation.expMonth = false;
            } else {
              $(".exp-month").css("border-bottom", "2px solid #d83e3b");
            }
            }
          } else {
            $(".exp-month").css("border-bottom", "2px solid #d83e3b");
            $scope.validation.expMonth = true;
          }
        };

        $scope.expYearValidate = function(value) {
          if(value) {
            if(value.length > 0) {
            var reg = new RegExp("^[0-9]{2}$");
            $scope.validation.expYear = true;
            if(reg.test(value)) {
              $(".exp-years").css("border-bottom", "2px solid #62e69a");
              $scope.validation.expYear = false;
            } else {
              $(".exp-years").css("border-bottom", "2px solid #d83e3b");
            }
            }
          } else {
            $(".exp-years").css("border-bottom", "2px solid #d83e3b");
            $scope.validation.expYear = true;
          }
        };

        $scope.cvvValidate = function(value) {
          if(value) {
            if(value.length > 0) {
            var reg = new RegExp("^[0-9]{3}$");
            $scope.validation.cvv = true;
            if(reg.test(value)) {
              $(".form-cvv").css("border-bottom", "2px solid #62e69a");
              $scope.validation.cvv = false;
            } else {
              $(".form-cvv").css("border-bottom", "2px solid #d83e3b");
            }
            }
          } else {
            $(".form-cvv").css("border-bottom", "2px solid #d83e3b");
            $scope.validation.cvv = true;
          }
        };

        $scope.changeState = function (states) {
            $scope.houseLayout.state = states;
        };
        if (Object.keys($scope.queryParamValues || {}).length === 0 && !$stateParams.blc_cid) {
            //if no params move to the root
            utilityService.redirect();
            return;
        }

        var custId = Number($scope.queryParamValues.blc_cid || $stateParams.blc_cid);
        if (isNaN(custId)) {
            utilityService.redirect();
            return;
        }

        customerService.getCart(custId).then(function (response) {
            var orderItemAttribute = {};
            $scope.cartObject = response.data;
            //var product = _.find($scope.cartObject.orderItem, {name: $scope.productName });
            var product = $scope.cartObject.orderItem[0];
            orderItemAttribute.firstName = _.find(product.orderItemAttribute, {name:'first-name' });
            $scope.homeLayout.firstName = orderItemAttribute.firstName.value;

            orderItemAttribute.lastName = _.find(product.orderItemAttribute, {name:'last-name' });
            $scope.homeLayout.lastName = orderItemAttribute.lastName.value;

            orderItemAttribute.address = _.find(product.orderItemAttribute, {name:'address' });
            var addressAttribute = JSON.parse(orderItemAttribute.address.value);
            $scope.homeLayout.street_add1 = addressAttribute.address1;
            $scope.homeLayout.street_add2 = addressAttribute.address2;
            $scope.homeLayout.city = addressAttribute.city;
            $scope.homeLayout.state = addressAttribute.state;
            $scope.homeLayout.zip = addressAttribute.zip;

            orderItemAttribute.email = _.find(product.orderItemAttribute, {name:'email' });
            $scope.homeLayout.email = orderItemAttribute.email.value;

            orderItemAttribute.date = _.find(product.orderItemAttribute, {name:'insurance-coverage-start-date' });
            $scope.homeLayout.date = orderItemAttribute.date.value;

            orderItemAttribute.no_of_occupants = _.find(product.orderItemAttribute, {name:'insurance-number-occupants' });
            $scope.homeLayout.no_of_occupants = orderItemAttribute.no_of_occupants.value;

            orderItemAttribute.no_of_animals = _.find(product.orderItemAttribute, {name:'insurance-number-animals' });
            $scope.homeLayout.no_of_animals = orderItemAttribute.no_of_animals.value;

            if ($scope.siteName === 'ses') {
                orderItemAttribute.clientId = _.find(product.orderItemAttribute, {name:'insurance-client' });
                $scope.homeLayout.clientId = orderItemAttribute.clientId.value;
            }


            if(!$scope.custId) {
                $scope.loaderIcon.show = true;
                $timeout(function() {
                orderItemAttribute.dog_bite_coverage = _.find(product.orderItemAttribute, {name: $scope.policyOptionWithBoolean.value });
                if (orderItemAttribute.dog_bite_coverage.value === "true") {
                    $scope.coverage.animalAmt = $scope.amountWithPets;
                    $scope.coverage.checkStatus = true;
                } else {
                    $scope.coverage.animalAmt = "None";
                }

                orderItemAttribute.insurance_contents_coverage = _.find(product.orderItemAttribute, {name: $scope.policyOptionWithSelect.value });
                if (orderItemAttribute.insurance_contents_coverage.value !== "None") {
                    var index = $scope.coverageValue.indexOf(orderItemAttribute.insurance_contents_coverage.value);
                    $scope.propertyCoverage.value = $scope.annualPremium[index];
                    $scope.isPersonalCoverage.value = true;
                    $scope.coverage.value = orderItemAttribute.insurance_contents_coverage.value
                } else {
                    $scope.propertyCoverage.value = "None";
                }
                $scope.totalAmount.value = parseInt($scope.cartObject.total.amount) + ".00";
                $scope.loaderIcon.show = false;
            }, 5000);
            }



            if (!$scope.cartObject.orderItem) {
                // if no cart items found move to root
                utilityService.redirect();
                return;
            }
        }, function () {
            notifyService.error('Cannot get cart!');
            utilityService.redirect();
            return;
        }).finally(function () {
            $scope.isLoading = false;
        });

        var errorCodes = $scope.queryParamValues.x_response_reason_code;
        if(errorCodes && errorCodes[0]) {
            var errorCode = errorCodes[0];
            var errorCodeArray = ['2', '4', '6', '7', '8', '17', '19', '20', '21', '22', '23', '25', '26', '27', '28', '36', '37', '39',
                                  '41', '44', '49', '64', '65', '165', '191', '200', '201', '202', '203', '204', '205', '206', '207', '208',
                                  '209', '210', '211', '212', '213', '214', '215', '216', '217', '218', '219', '220', '221', '222', '223',
                                  '224', '250', '251', '254', '295', '315', '316', '317'];

            if (errorCodeArray.includes(errorCode)) {
                $scope.trasaction = {
                    isError: true,
                    errorMessage: $scope.queryParamValues.x_response_reason_text
                };

            } else {
                $scope.trasaction = {
                    isError: true,
                    errorMessage: "There was a problem processing your payment due to a system error. Please try again."
                };
            }
        }
        $scope.queryParam = {};
        $scope.isBillingSame = true;
        $scope.agreeTerms = false;
        $scope.emailRegEx = new RegExp('^[a-zA-Z0-9._%+-]+@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$');
        $scope.creditCardExp = {
         'expirationMonth': ['01','02','03','04','05','06','07','08','09','10','11','12'],
         'expirationYears': getCreditYears()
        };

        function getOrderItemAttributes(orderItemAttribute) {
            var obj = {};
            for (i = 0; i < orderItemAttribute.length; i++) {
                var orderItemArr = orderItemAttribute[i];
                if (orderItemArr.name === 'address') {
                    var address = JSON.parse(orderItemArr.value);
                    for (var val in address) {
                        if (!obj.address) {
                            angular.extend(obj, {
                                address: {}
                            });
                        }
                        obj.address[val] = address[val];
                    }
                } else {
                    obj[orderItemArr.name] = orderItemArr.value;
                }
            }

            return obj;
        }

        function getCreditYears() {
            var years = [],
            date = new Date().getYear() - 100;

            for (var i = date; i <= (date + 20); i++) {
                years.push(String(i));
            }
            return years;
        }
        $scope.isBillingAddressSame = function () {
          $scope.houseLayout.firstName = $scope.homeLayout.firstName;
          $scope.houseLayout.lastName = $scope.homeLayout.lastName;
          $scope.houseLayout.street_add1 = $scope.homeLayout.street_add1;
          $scope.houseLayout.street_add2 = $scope.homeLayout.street_add2;
          $scope.houseLayout.city = $scope.homeLayout.city;
          $scope.houseLayout.state = $scope.homeLayout.state;
          $scope.houseLayout.zip = $scope.homeLayout.zip;
        };
        $scope.billingAddrressValidate = function() {
            if($scope.houseLayout.firstName) {
                $scope.validation.first_name = false;
            }
            if($scope.houseLayout.lastName) {
                $scope.validation.last_name = false;
            }
            if($scope.houseLayout.street_add1) {
                $scope.validation.address_1 = false;
            }
            if($scope.houseLayout.city) {
                $scope.validation.city = false;
            }
            if($scope.houseLayout.state) {
                $scope.validation.state = false;
            }
            if($scope.houseLayout.zip) {
                $scope.validation.zip = false;
            }
        };

        $scope.placeOrder = function() {
            // if (!$scope.cartObject && !reviewOrderForm.$invalid && !$scope.agreeTerms) {
            //     return;
            // }

            var customerId = $scope.cartObject.customer.id;
            var orderId = $scope.cartObject.id;
            var amount = Number($scope.totalAmount.value);
            var orderItemId = $scope.cartObject.orderItem[0].id;
            $scope.paymentInfo.date = $filter('date')($scope.homeLayout.date, "MM/dd/yyyy");

            if(!$scope.paymentInfo.cardNumber) {
              $scope.validation.cardNumber = true;
              return;
            }
            if(!$scope.paymentInfo.expirationMonth) {
              $scope.validation.expMonth = true;
              return;
            }
            if(!$scope.paymentInfo.expirationYears) {
              $scope.validation.expYear = true;
              return;
            }
            if(!$scope.paymentInfo.cvv) {
              $scope.validation.cvv = true;
              return;
            }
            if(!$scope.houseLayout.firstName) {
              $scope.validation.first_name = true;
              return;
            }
            if(!$scope.houseLayout.lastName) {
              $scope.validation.last_name = true;
              return;
            }
            if(!$scope.houseLayout.street_add1) {
              $scope.validation.address_1 = true;
              return;
            }
            if(!$scope.houseLayout.city) {
              $scope.validation.city = true;
              return;
            }
            if(!$scope.houseLayout.state) {
              $scope.validation.state = true;
              return;
            }
            if(!$scope.houseLayout.zip) {
              $scope.validation.zip = true;
              return;
            }
            $scope.loaderIcon.show = true;

            if ($scope.siteName === 'ses') {
                valuationService.getMasterPolicy($scope.homeLayout.clientId, $scope.siteName, $scope.dynamicTags.productName).then(function (dataValue) {
                    $scope.masterPolicy = dataValue.data.propertyValue;
                });
            }
            customerService.getCart(customerId).then(function (response) {
                  $scope.cartObject = response.data;
                  if ($scope.cartObject.orderItem) {
                    var orderItemId = $scope.cartObject.orderItem[0].id;
                      // if no cart items found move to root
                      customerService.deletCartItem(customerId, orderItemId).then(function (response) {
                          addProductToCart(customerId);
                          $scope.custId = customerId;
                      }, function (error) {

                      });
                  } else {
                    addProductToCart(customerId);
                    $scope.custId = customerId;
                  }

              }, function (error) {
                $scope.custId = customerId;
                addProductToCart(customerId);
              });

          function addProductToCart(customerId) {
              if (!customerId) {
                  return;
              }
              if($scope.coverage.value === null || $scope.coverage.value === undefined || $scope.coverage.value === "" ) {
                  $scope.coverage.value = "None";
              }
              var policyOptionWithBoolean = $scope.policyOptionWithBoolean.value;
              var policyOptionWithSelect = $scope.policyOptionWithSelect.value;

              var data = {
                  'first-name': $scope.homeLayout.firstName === undefined ? "": $scope.homeLayout.firstName,
                  'last-name': $scope.homeLayout.lastName === undefined ? "": $scope.homeLayout.lastName,
                  'email': $scope.homeLayout.email === undefined ? "": $scope.homeLayout.email,
                  'insurance-coverage-start-date': $scope.homeLayout.date === undefined ? "": $scope.homeLayout.date,

                  'insurance-number-occupants': $scope.homeLayout.no_of_occupants === undefined ? "": $scope.homeLayout.no_of_occupants,
                  'insurance-number-animals': $scope.homeLayout.no_of_animals === undefined ? "0": $scope.homeLayout.no_of_animals,
                  'address': {
                      'address1': $scope.homeLayout.street_add1 === undefined ? "": $scope.homeLayout.street_add1,
                      'address2': $scope.homeLayout.street_add2 === undefined ? "": $scope.homeLayout.street_add2,
                      'city': $scope.homeLayout.city === undefined ? "": $scope.homeLayout.city,
                      'state': $scope.homeLayout.state === undefined ? "": $scope.homeLayout.state,
                      'zip': $scope.homeLayout.zip === undefined ? "": $scope.homeLayout.zip
                  }
              };
              data[policyOptionWithBoolean] = $scope.coverage.checkStatus  === undefined ? "false": $scope.coverage.checkStatus;
              data[policyOptionWithSelect] = $scope.coverage.value;
              if ($scope.siteName === 'ses') {
                  var masterPolicy = 'insurance-master-policy';
                  var clientId = 'insurance-client';
                  data[masterPolicy] = $scope.masterPolicy;
                  data[clientId] = $scope.homeLayout.clientId;
              }

              for (i = 0; i < $scope.optionalProductOption.length; i++) {
                  data[$scope.optionalProductOption[i].key] = $scope.optionalProductOption[i].value;
              }

              $http({
                  method: 'POST',
                  url: '/cart/enhanced/'+$scope.productId+'?categoryId='+$scope.categoryId+'&customerId='+customerId,
                  headers:{
                      'Content-Type':'application/json'
                  },
                  data:data
              }).then(function (response) {
                  // $state.go('place-order');
                  $http({
                      method: 'GET',
                      url: '/checkout/paymentAuthDetails',
                      headers:{
                          'Content-Type':'application/json',
                          'orderId': orderId,
                          'customerId': customerId,
                          'amount': amount
                      },
                      data:{}
                  }).then(function(response) {
                      var data = response.data;
                      var billingAddr = {
                          street : $scope.houseLayout.street_add1,
                          apartment: $scope.houseLayout.street_add2,
                          city : $scope.houseLayout.city,
                          state : $scope.houseLayout.state,
                          zipCode : $scope.houseLayout.zip
                      };

                      if (!$scope.isBillingSame) {
                          billingAddr = {
                              street : $scope.b_address.street,
                              city : $scope.b_address.city,
                              state : $scope.b_address.state,
                              zipCode : $scope.b_address.zipCode
                          };
                      }

                      var queryParam = {
                          'authorizenet_server_url': data.responseMap.authorizenet_server_url,
                          'x_card_num':  $scope.paymentInfo.cardNumber,
                          'x_card_code': $scope.paymentInfo.cvv,
                          'creditCard.creditCardHolderName': $scope.houseLayout.firstName,
                          'x_exp_date':  $scope.paymentInfo.expirationMonth+'/'+$scope.paymentInfo.expirationYears,
                          'blc_cid': data.responseMap.blc_cid,
                          'blc_oid': data.responseMap.blc_oid,
                          'blc_tps': data.responseMap.blc_tps,
                          'x_address': billingAddr.street,
                          'x_apartment': billingAddr.apartment,
                          'x_amount': data.responseMap.x_amount,
                          'x_city': billingAddr.city,
                          'x_country':'US',
                          'x_cust_id': data.responseMap.x_cust_id,
                          'x_description': data.responseMap.x_description,
                          'x_email': $scope.homeLayout.email,
                          'x_first_name': $scope.houseLayout.firstName,
                          'x_fp_hash': data.responseMap.x_fp_hash,
                          'x_fp_sequence': data.responseMap.x_fp_sequence,
                          'x_fp_timestamp': data.responseMap.x_fp_timestamp,
                          'x_invoice_num': data.responseMap.x_invoice_num,
                          'x_last_name': $scope.houseLayout.lastName,
                          'x_login': data.responseMap.x_login,
                          'x_method': data.responseMap.x_method,
                          'x_phone': "",
                          'x_relay_response': data.responseMap.x_relay_response,
                          'x_relay_url': data.responseMap.x_relay_url,
                          'x_state': billingAddr.state,
                          'x_test_request': data.responseMap.x_test_request,
                          'x_trans_id': data.responseMap.x_trans_id,
                          'x_type': data.responseMap.x_type,
                          'x_version': data.responseMap.x_version,
                          'x_zip': billingAddr.zipCode
                      };

                      $scope.queryParam = queryParam;
                      $('.transact').attr('action', $scope.queryParam.authorizenet_server_url);
                      $timeout(function (argument) {
                          $('.transact').submit();
                      }, 200);

                  }, function(error) {
                      customerService.deletCartItem(customerId, orderItemId).finally(function () {
                          notifyService.error('Error : Cannot Delete Cart Item');
                          $scope.loaderIcon.show = false;

                      });

                  });
              }, function (error) {
                  if (error.status !== 404) {
                      $scope.loaderIcon.show = false;
                      return;
                  }

                  customerService.createCart(customerId).then(function (customerId) {
                      addProductToCart(customerId);
                  }, function (error) {

                  });
              });
          }
        };
}]);
