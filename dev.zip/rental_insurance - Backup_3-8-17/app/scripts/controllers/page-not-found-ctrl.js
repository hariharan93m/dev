app.controller('pageNotFoundCtrl' ,
    ['$scope','customerService', '$window',
      function($scope, customerService, $window) {
          customerService.getDynamicProduct().then(function (response) {
              var dynamicCategory = {};
              dynamicCategory.name = response.data.categoryName;
              $scope.dynamicTags.productName = response.data.productName;
              dynamicCategory.policyOptionWithBoolean = response.data.policyOptionWithBoolean;
              var poSplit = dynamicCategory.policyOptionWithBoolean.split('.');
              $scope.policyOptionWithBoolean.value = poSplit[1];

              dynamicCategory.policyOptionWithSelect = response.data.policyOptionWithSelect;
              var poSplit = dynamicCategory.policyOptionWithSelect.split('.');
              $scope.policyOptionWithSelect.value = poSplit[1];

              $scope.optionalProductOption = response.data.optionalProductOption;

              $scope.dynamicTags.mainHeader = response.data.mainHeader;
              $window.document.title = "Purchase " +response.data.mainHeader;
              $scope.dynamicTags.siteUrl = response.data.siteUrl;
              $scope.dynamicTags.returnHomeButton = response.data.returnHomeButton;

          });
      }]);
