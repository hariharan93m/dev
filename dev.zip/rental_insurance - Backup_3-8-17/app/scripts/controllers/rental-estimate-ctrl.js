app.controller('RentalEstimateCtrl' ,
    ['$scope',
    '$filter',
     '$http',
     'valuationService',
     '$state',
     'customerService',
     '$window',
     '$location',
      function($scope, $filter, $http, valuationService, $state, customerService, $window, $location) {
        var categoryId,
            productId;
            $scope.address = {};
        $scope.error = {};
        $scope.phoneRegEx = new RegExp("^[0-9]{10}");
        $scope.emailRegEx = new RegExp('^[a-zA-Z0-9._%+-]+@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$');
        $scope.zipRegEx = new RegExp('^[0-9]{5}');
        $scope.productOptions = {};
        $scope.productOptions.states = [];
        $scope.coverage = {};
        $scope.liablityInsurance = false;
        $scope.propertyCoverage = {};
        $scope.propertyCoverage.value = "None";
        $scope.coverage.animalAmt = "None";
        $scope.dollar = false;
        $scope.totalAmount.value = "None";
        $scope.loaderIcon = {};
        $scope.coverVal = $state.params.coverageValue;
        $scope.propertyCoverval = $state.params.propertyCoverageval;
        $scope.totalval = $state.params.totalAmountval;
        $scope.isOrdersummary = false;
        var dynamicCategory = {};

        $scope.queryParamValues = $location.search();
        if(!(_.isEmpty($scope.queryParamValues))) {
            $scope.homeLayout.firstName = ($scope.queryParamValues.firstName ? $scope.queryParamValues.firstName : "").trim();
            $scope.homeLayout.lastName = ($scope.queryParamValues.lastName ? $scope.queryParamValues.lastName : "").trim();
            $scope.homeLayout.date = ($scope.queryParamValues.coverageStartDate ? $scope.queryParamValues.coverageStartDate : "").trim();
            $scope.homeLayout.no_of_occupants = ($scope.queryParamValues.numberOfOccupants ? $scope.queryParamValues.numberOfOccupants : "").trim();
            $scope.homeLayout.no_of_animals = ($scope.queryParamValues.numberOfPets ? $scope.queryParamValues.numberOfPets : "").charAt(0);
            $scope.homeLayout.street_add1 = $scope.queryParamValues.rentalPropertyAddress ? $scope.queryParamValues.rentalPropertyAddress : "";
            $scope.homeLayout.street_add2 = $scope.queryParamValues.address2 ? $scope.queryParamValues.address2 : "";
            $scope.homeLayout.city = $scope.queryParamValues.city ? $scope.queryParamValues.city : "";
            $scope.homeLayout.zip = ($scope.queryParamValues.zip ? $scope.queryParamValues.zip : "").trim();
            $scope.homeLayout.email = ($scope.queryParamValues.email ? $scope.queryParamValues.email : "").trim();
        }

        $scope.setStateValue = function() {
            if($scope.queryParamValues.state){
                var state = $scope.queryParamValues.state ? $scope.queryParamValues.state : "";
                $scope.homeLayout.state = state.trim();
            }
        };

        customerService.getDynamicProduct().then(function (response) {

            dynamicCategory.name = response.data.categoryName;
            $scope.dynamicTags.productName = response.data.productName;
            dynamicCategory.policyOptionWithBoolean = response.data.policyOptionWithBoolean;
            var poSplit = dynamicCategory.policyOptionWithBoolean.split('.');
            $scope.policyOptionWithBoolean.value = poSplit[1];

            dynamicCategory.policyOptionWithSelect = response.data.policyOptionWithSelect;
            var poSplit = dynamicCategory.policyOptionWithSelect.split('.');
            $scope.policyOptionWithSelect.value = poSplit[1];

            $scope.optionalProductOption = response.data.optionalProductOption;

            $scope.dynamicTags.mainHeader = response.data.mainHeader;
            $window.document.title = "Purchase " +response.data.mainHeader;
            $scope.dynamicTags.bottomNote = response.data.bottomNote;
            $scope.dynamicTags.descriptionOne = response.data.descriptionOne;
            $scope.dynamicTags.descriptionTwo = response.data.descriptionTwo;
            $scope.dynamicTags.faqLink = response.data.faqLink;
            $scope.dynamicTags.faqName = response.data.faqName;
            $scope.dynamicTags.headerTwo = response.data.headerTwo;
            $scope.dynamicTags.howMuchPopUp = response.data.howMuchPopUp;
            $scope.dynamicTags.offeredBy = response.data.offeredBy;
            $scope.dynamicTags.siteUrl = response.data.siteUrl;
            $scope.dynamicTags.whatDoesPopup = response.data.whatDoesPopup;
            $scope.dynamicTags.mandatoryCoverageHeader = response.data.mandatoryCoverageHeader;
            $scope.dynamicTags.optionalCoverageHeader = response.data.optionalCoverageHeader;
            $scope.dynamicTags.termsOfUse = response.data.termsOfUse;
            $scope.dynamicTags.privacyPolicy = response.data.privacyPolicy;
            $scope.dynamicTags.contactNumber = response.data.contactNumber;
            $scope.dynamicTags.contactAddress = response.data.contactAddress;
            $scope.dynamicTags.faqText = response.data.faqText;
            $scope.dynamicTags.tagLine = response.data.tagLine;
            $scope.dynamicTags.clientIdText = response.data.clientIdText;
            $scope.dynamicTags.gtmId = response.data.gtmId;
            $scope.dynamicTags.gaId = response.data.gaId;

            var host = $location.host();
            if (host.indexOf('ses') === 0){
                $scope.siteName = 'ses';
                $scope.siteIdentifier.value = 'ses';
            } else {
                $scope.siteIdentifier.value = 'rhss';
            }
            gtmId = $scope.dynamicTags.gtmId;
            gaId =  $scope.dynamicTags.gaId;
            $('head').append('<script type="text/javascript" src="assets/js/gtm.js"></script>');
            $('head').append('<script type="text/javascript" src="assets/js/ga.js"></script>');
});
        getParentCategories();

        //widget
        $scope.tabs = [{
           title: 'Select Options',
           url: 'one.tpl.html'
               }, {
                   title: 'Enter Details',
                   url: 'two.tpl.html'
               }, {
                   title: 'Place Your Order',
                   url: 'three.tpl.html'
           }];

           $scope.currentTab = 'one.tpl.html';

           $scope.occupants = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];
           $scope.onStreetAddressValidate = function(value) {
              if(value) {
                if(value.length > 0) {
                var reg = new RegExp("^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$");
                $scope.validation.address_1 = true;
                if(reg.test(value)) {
                  $(".address-1").css("border-bottom", "2px solid #62e69a");
                  $scope.validation.address_1 = false;
                } else {
                  $(".address-1").css("border-bottom", "2px solid #d83e3b");
                }
                }
              } else {
                $(".address-1").css("border-bottom", "2px solid #d83e3b");
                $scope.validation.address_1 = true;
              }
           };

           $scope.onFirstNameValidate = function(value) {
              if(value) {
                    if(value.length > 0) {
                    var reg = new RegExp("^[a-zA-Z ]*$");
                    $scope.validation.first_name = true;
                    if(reg.test(value)) {
                      $(".form-first-name").css("border-bottom", "2px solid #62e69a");
                      $scope.validation.first_name = false;
                    } else {
                      $(".form-first-name").css("border-bottom", "2px solid #d83e3b");
                    }
                  }
              } else {
                $(".form-first-name").css("border-bottom", "2px solid #d83e3b");
                $scope.validation.first_name = true;
              }
           };

           $scope.onAptValidate = function(value) {
            if(value) {
                var reg = new RegExp("^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$");
                $scope.validation.aptAddress = true;
                if(reg.test(value)) {
                  $(".address-2").css("border-bottom", "2px solid #62e69a");
                  $scope.validation.aptAddress = false;
                } else {
                  $(".address-2").css("border-bottom", "2px solid #d83e3b");
                }
              } else {
                $(".address-2").css("border-bottom", "");
                $scope.validation.aptAddress = false;
              }
           };

           $scope.onLastNameValidate = function(value) {
              if(value) {
                if(value.length > 0) {
                var reg = new RegExp("^[a-zA-Z ]*$");
                $scope.validation.last_name = true;
                if(reg.test(value)) {
                  $(".form-last-name").css("border-bottom", "2px solid #62e69a");
                  $scope.validation.last_name = false;
                } else {
                  $(".form-last-name").css("border-bottom", "2px solid #d83e3b");
                }
                }
              } else {
                $(".form-last-name").css("border-bottom", "2px solid #d83e3b");
                $scope.validation.last_name = true;
              }
           };

           $scope.onCityValidate = function(value) {
             if(value) {
               if(value.length > 0) {
               var reg = new RegExp("^[a-zA-Z ]*$");
               $scope.validation.city = true;
               if(reg.test(value)) {
                 $(".form-city").css("border-bottom", "2px solid #62e69a");
                 $scope.validation.city = false;
               } else {
                 $(".form-city").css("border-bottom", "2px solid #d83e3b");
               }
               }
             } else {
               $(".form-city").css("border-bottom", "2px solid #d83e3b");
               $scope.validation.city = true;
             }
           };

           $scope.onZipValidate = function(value) {
               if(value) {
                 if(value.length > 0) {
                 var reg = new RegExp("^[0-9]{5}$");
                 $scope.validation.zip = true;
                 if(reg.test(value)) {
                   $(".form-zip").css("border-bottom", "2px solid #62e69a");
                   $scope.validation.zip = false;
                 } else {
                   $(".form-zip").css("border-bottom", "2px solid #d83e3b");
                 }
                 }
               } else {
                 $(".form-zip").css("border-bottom", "2px solid #d83e3b");
                 $scope.validation.zip = true;
               }
           };
           $scope.onEmailValidate = function(value) {
               if(value) {
                   if(value.length > 0) {
                   var reg = new RegExp("^[a-zA-Z0-9._%+-]+@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$");
                   $scope.validation.email = true;
                   if(reg.test(value)) {
                     $(".form-email").css("border-bottom", "2px solid #62e69a");
                     $scope.validation.email = false;
                   } else {
                     $(".form-email").css("border-bottom", "2px solid #d83e3b");
                   }
                 }
               } else {
                 $(".form-email").css("border-bottom", "2px solid #d83e3b");
                 $scope.validation.email = true;
               }
           };

          $scope.onOccupantsValidate = function(value) {
            if(value) {
                var reg = new RegExp("^[0-9]*$");
                $scope.validation.occupants = true;
                if(reg.test(value)) {
                    $(".form-occupants").css("border-bottom", "2px solid #62e69a");
                    $scope.validation.occupants = false;
                } else {
                    $(".form-occupants").css("border-bottom", "2px solid #d83e3b");
                }
            } else {
                   $(".form-occupants").css("border-bottom", "");
                   $scope.validation.occupants = false;
                 }
          };
          $scope.onAnimalCountValidate = function(value) {
            if(value && value !== "0") {
                var reg = new RegExp("^[0-9]\d*$");
                $scope.validation.animals = true;
                if(reg.test(value)) {
                    $(".form-animals").css("border-bottom", "2px solid #62e69a");
                    $scope.validation.animals = false;
                } else {
                    $(".form-animals").css("border-bottom", "2px solid #d83e3b");
                }
            } else {
                   $(".form-animals").css("border-bottom", "2px solid #d83e3b");
                   $scope.validation.animals = true;
            }
        };

        $scope.onNumberofPetsValidate = function(value) {
          if(value) {
              var reg = new RegExp("^[0-9]\d*$");
              $scope.validation.animals = true;
              if(reg.test(value)) {
                  $(".form-animals").css("border-bottom", "2px solid #62e69a");
                  $scope.validation.animals = false;
              } else {
                  $(".form-animals").css("border-bottom", "2px solid #d83e3b");
              }
          } else {
                 $(".form-animals").css("border-bottom", "");
                 $scope.validation.animals = false;
          }
      };

           $scope.onStateChange = function(value) {
             if(value) {
               if(value.length > 0) {
                   $scope.validation.state = true;
                   $(".form-state").css("border-bottom", "2px solid #62e69a");
                   $scope.validation.state = false;
               }
              } else {
               $(".form-state").css("border-bottom", "2px solid #d83e3b");
                $scope.validation.state = true;
             }
           };

           $scope.onDateValidate = function(val) {
               $scope.validation.date = false;
               setTimeout(function(){
                 if($scope.homeLayout.date) {
                   $(".form-date").css("border-bottom", "2px solid #62e69a");
                 }
               }, 1000);

           };

           $scope.onClickTab = function (tabUrl) {
             if(tabUrl === 'one.tpl.html') {
               if($scope.tabOneActive) {
                  //$scope.tabOne = true;
                  $scope.tabTwo = false;
                  $scope.currentTab = 'one.tpl.html';
                  $(".tab-one").css("background-color", "#ED6B00");
                  $(".number-one-circle").css("border", "2px solid #ED6B00");
                  $(".number-one-circle").css("color", "#ED6B00");
                  $(".tab-two").css("background-color", "#C39C7C");
                  $(".number-two-circle").css("border", "2px solid #CCCCCC");
                  $(".number-two-circle").css("color", "#CCCCCC");
                  $(".number-three-circle").css("border", "2px solid #CCCCCC");
                  $(".number-three-circle").css("color", "#CCCCCC");
                  $scope.buyItBtn.show = false;
                }
             } else if(tabUrl === 'two.tpl.html') {
                if ($scope.tabTwoActive && !($scope.currentTab === 'one.tpl.html')) {
                  $scope.tabThree = false;
                  $(".tab-two").css("background-color", "#ED6B00");
                  $(".number-two-circle").css("border", "2px solid #ED6B00");
                  $(".number-two-circle").css("color", "#ED6B00");
                  $(".tab-one").css("background-color", "#C39C7C");
                  $(".number-one-circle").css("border", "2px solid #CCCCCC");
                  $(".number-one-circle").css("color", "#CCCCCC");
                  $(".number-three-circle").css("border", "2px solid #CCCCCC");
                  $(".number-three-circle").css("color", "#CCCCCC");
                  $scope.buyItBtn.show = false;
                  $scope.currentTab = 'two.tpl.html';
                }
            }
           };

           $scope.nextTab = function (tabUrl) {
                if(tabUrl === 'two.tpl.html') {
                  $(".tab-one").css("background-color", "#C39C7C");
                  $(".number-one-circle").css("border", "2px solid #CCCCCC");
                  $(".number-one-circle").css("color", "#CCCCCC");
                  $(".tab-two").css("background-color", "#ED6B00");
                  $(".number-two-circle").css("border", "2px solid #ED6B00");
                  $(".number-two-circle").css("color", "#ED6B00");
                  $scope.tabOneActive = true;
                  $scope.isStreetFocused = true;
                  // $scope.tabOne = false;
                }
                $scope.currentTab = tabUrl;
           };

           $scope.isActiveTab = function(tabUrl) {
               return tabUrl == $scope.currentTab;
           };
           $scope.isPersonalCoverage.value = false;

           $scope.checkPersonalCoverage = function() {
               if (!$scope.isPersonalCoverage.value) {
                   $scope.isPersonalCoverage.value = true;
               } else {
                   if($scope.propertyCoverage.value !== "None")
                   $scope.totalAmount.value = parseFloat($scope.totalAmount.value) - parseFloat($scope.propertyCoverage.value);
                   $scope.isPersonalCoverage.value = false;
                   $scope.propertyCoverage.value = "None";
                   $scope.coverage.value = null;
               }
           };

           $scope.buyIt = function() {
             $scope.$broadcast ('buyEvent');
           };

           $scope.addToOrderSummary = function() {
              if (!$scope.liablityInsurance) {
                  $scope.liablityInsurance = true;
                  $scope.coverage.value = null;
                  $scope.dollar = true;
              } else {
                $scope.liablityInsurance = false;
                $scope.propertyCoverage.value = "None";
                $scope.dollar = false;
                $scope.totalAmount.value = "None";
                $scope.decTwo = false;
                // if($scope.checked) {
                //   $scope.checked = false;
                // }
              }
           };

            $scope.removeCartValues = function(val, personalProperty) {
                if(personalProperty) {
                    $scope.propertyCoverage.value = "None";
                    $scope.coverage.value = null;
                    $scope.isPersonalCoverage.value = false;
                    $scope.dollar = false;
                } else {
                    $scope.coverage.animalAmt = "None";
                    $scope.coverage.checkStatus = false;
                    $scope.validation.animals = false;
                    $scope.homeLayout.no_of_animals = undefined;
                }
                $scope.totalAmount.value = $scope.totalAmount.value - parseFloat(val);
                if ($scope.totalAmount.value % 1 != 0) {
                    $scope.decTwo = false;
                } else {
                    $scope.decTwo = true;
                }
            };

           $scope.newPersonalCoverage = function(val) {
                if($scope.propertyCoverage.value !== "None") {
                   $scope.totalAmount.value = $scope.totalAmount.value - parseFloat($scope.propertyCoverage.value);
                }
                var index = $scope.coverageValue.indexOf(val);
                $scope.propertyCoverage.value = $scope.annualPremium[index];
                $scope.dollar = true;
                $scope.totalAmount.value = parseFloat($scope.totalAmount.value) + parseFloat($scope.propertyCoverage.value);
                if($scope.totalAmount.value % 1 != 0) {
                    $scope.decTwo = false;
                } else {
                    $scope.decTwo = true;
                }
            // $scope.totalAmount.value = totalAmount;
            };

            $scope.onAnimalBiteCoverage = function(val, animalCoverage) {
                if(animalCoverage) {
                    $scope.totalAmount.value = parseFloat($scope.totalAmount.value) + parseFloat(val);
                    if($scope.totalAmount.value % 1 != 0) {
                        $scope.decTwo = false;
                    } else {
                        $scope.decTwo = true;
                    }
                    $scope.coverage.animalAmt = val;
                } else {
                    $scope.removeCartValues(val);
                }
            };

            var clientIdError = false;

            $scope.onclientIdValidate = function(val) {
                if(clientIdError) {
                    return;
                }

                if(!val) {
                    $scope.validation.clientId = true;
                    $(".form-clientId").css("border-bottom", "2px solid #d83e3b");
                    return;
                } else {
                    $scope.validation.clientId = false;
                    $(".form-clientId").css("border-bottom", "2px solid #62e69a");
                }
            };

            //Mobile toggle order summary section
            $scope.toggleOrderSummary = function () {
                if($scope.isOrdersummary) {
                    $scope.isOrdersummary = false;
                } else {
                    $scope.isOrdersummary = true;
                }
            };
        function getParentCategories() {
            valuationService.getParentCategoryValues().then(function (dataValue) {
                var category = _.find(dataValue.data.category, {name: dynamicCategory.name });
                categoryId = category.id;
                $scope.categoryId = categoryId;
                valuationService.productValues(categoryId).then(function (dataValue) {
                    var product = dataValue.data;
                    var stateValue = [];
                    var coverageValue = [];
                    var annualPremium = [];
                    var product = _.find(dataValue.data.product, {name: $scope.dynamicTags.productName });
                    $scope.productName = product.name;
                    var freeValuation = _.each(product.productOption, function(allowedValue){});
                    $scope.retailPrice = product.retailPrice.amount;
                    if ($scope.totalAmount.value === "None") {
                        $scope.totalAmount.value = $scope.retailPrice;
                    }
                    var productaddress = _.find(freeValuation,{attributeName: 'productOption.address'});
                    var allowedValue = _.each(productaddress.allowedValue, function(allowedValue){
                        stateValue.push(allowedValue.attributeValue);
                    });
                    $scope.productOptions.states = stateValue;
                    var personalCoverage = _.find(freeValuation,{attributeName: dynamicCategory.policyOptionWithSelect});
                    var allowedValue = _.each(personalCoverage.allowedValue, function(allowedValue){
                        if (allowedValue.attributeValue !== "None") {
                          coverageValue.push(allowedValue.attributeValue);
                          annualPremium.push(allowedValue.priceAdjustment.amount);
                        }
                    });
                    var animalCoverageAmount = _.find(freeValuation,{attributeName: dynamicCategory.policyOptionWithBoolean});
                    var allowedValue = _.each(animalCoverageAmount.allowedValue, function(allowedValue){
                        if (allowedValue.attributeValue === "false") {
                        //   coverageValue.push(allowedValue.attributeValue);
                          $scope.amountWithnoPets = allowedValue.priceAdjustment.amount;
                      } else if(allowedValue.attributeValue === "true") {
                          $scope.amountWithPets = allowedValue.priceAdjustment.amount;
                      }
                    });
                    $scope.coverageValue = coverageValue;
                    $scope.annualPremium = annualPremium;
                    // $scope.productOptions.
                    $scope.productId = product.id;
                    $scope.productOptionLabel = getProductOptionLabels(product.productOption);
                    $scope.requiredPoType = requiredPoType(product.productOption);
                });
            }, function (error) {
                $state.go('not-available');
            });
        }
        function getProductOptionLabels(po) {
            var obj = {};
            for (var i = 0; i < po.length; i++) {
                var poSplit = po[i].attributeName.split('.');
                if (poSplit.length > 1) {
                    obj[poSplit[1]] = po[i].label;
                    continue;
                }
                obj[String(i)] = po[i].label;
            }
            return obj;
        }

        function requiredPoType(po) {
            var obj = {};
            for (var i = 0; i < po.length; i++) {
                var poSplit = po[i].attributeName.split('.');
                if (poSplit.length > 1) {
                    obj[poSplit[1]] = po[i].required;
                    continue;
                }
                obj[String(i)] = po[i].required;
            }
            return obj;
        }

        $scope.addToCart = function() {

            //get cust Id
            $scope.onFirstNameValidate($scope.homeLayout.firstName);
            $scope.onLastNameValidate($scope.homeLayout.lastName);
            $scope.onStreetAddressValidate($scope.homeLayout.street_add1);
            $scope.onAptValidate($scope.homeLayout.street_add2);
            $scope.onCityValidate($scope.homeLayout.city);
            $scope.onZipValidate($scope.homeLayout.zip);
            //$scope.onEmailValidate($scope.homeLayout.email);
            $scope.onOccupantsValidate($scope.homeLayout.no_of_occupants);
            var emailReg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            if ($scope.homeLayout.email && !emailReg.test($scope.homeLayout.email)) {
                $scope.validation.email = true;
                $(".form-email").css("border-bottom", "2px solid #d83e3b");
            }

            //$scope.homeLayout.street_add1 === undefined ? "": $scope.homeLayout.street_add1;
            if ($scope.policyOptionWithBoolean.value === 'insurance-dog-bite-coverage'){
                if (!$scope.coverage.checkStatus){
                    $scope.homeLayout.no_of_animals = undefined;
                } else {
                    $scope.onAnimalCountValidate($scope.homeLayout.no_of_animals);
                }
                if ($scope.coverage.checkStatus) {
                    if (!$scope.homeLayout.no_of_animals) {
                        $scope.validation.animals = true;
                        $(".form-animals").css("border-bottom", "2px solid #d83e3b");
                        return;
                    }
                    if ($scope.homeLayout.no_of_animals === "0") {
                        $scope.validation.animals = true;
                        $(".form-animals").css("border-bottom", "2px solid #d83e3b");
                        return;
                    }
                }
            } else {
                $scope.onNumberofPetsValidate($scope.homeLayout.no_of_animals);
            }

            if (!$scope.homeLayout.email || $scope.validation.email) {
                $scope.validation.email = true;
                return;
            }
            if (!$scope.homeLayout.date || $scope.validation.date) {
                $scope.validation.date = true;
                return;
            }
            if (new Date($scope.homeLayout.date).toString() === "Invalid Date") {
                $scope.validation.date = true;
                $(".form-date").css("border-bottom", "2px solid #d83e3b");
                return;
            }
            if (!$scope.homeLayout.firstName || $scope.validation.first_name) {
                $scope.validation.first_name = true;
                return;
            }
            if (!$scope.homeLayout.lastName || $scope.validation.last_name) {
                $scope.validation.last_name = true;
                return;
            }
            if ($scope.validation.occupants) {
                return;
            }
            if ($scope.validation.animals) {
                return;
            }

            $scope.updateCart = function () {

            $scope.validation.email = false;
            $scope.validation.date = false;
            $scope.addressError = {};
            $scope.loaderIcon.show = true;

            $scope.homeLayout.date = $filter('date')($scope.homeLayout.date, "MM/dd/yyyy");
            customerService.getCustomerId({
                'firstName'      : $scope.homeLayout.firstName,
                'lastName'       : $scope.homeLayout.lastName,
                'emailAddress'   : $scope.homeLayout.email,
            }).then(function (customerId) {
              customerService.getCart(customerId).then(function (response) {
                    $scope.cartObject = response.data;
                    if ($scope.cartObject.orderItem) {
                      var orderItemId = $scope.cartObject.orderItem[0].id;
                        // if no cart items found move to root
                        customerService.deletCartItem(customerId, orderItemId).then(function (response) {
                            addProductToCart(customerId);
                            $scope.custId = customerId;
                        }, function (error) {

                        });
                    } else {
                      addProductToCart(customerId);
                      $scope.custId = customerId;
                    }

                }, function (error) {
                  $scope.custId = customerId;
                  addProductToCart(customerId);
                });

            }, function (error) {
                // $scope.loaderIcon.show = false;
            });
            function addProductToCart(customerId) {
                if (!customerId) {
                    return;
                }
                if($scope.coverage.value === null || $scope.coverage.value === undefined || $scope.coverage.value === "" ) {
                    $scope.coverage.value = "None";
                }

                var policyOptionWithBoolean = $scope.policyOptionWithBoolean.value;
                var policyOptionWithSelect = $scope.policyOptionWithSelect.value;

                var data = {
                    'first-name': $scope.homeLayout.firstName === undefined ? "": $scope.homeLayout.firstName,
                    'last-name': $scope.homeLayout.lastName === undefined ? "": $scope.homeLayout.lastName,
                    'email': $scope.homeLayout.email === undefined ? "": $scope.homeLayout.email,
                    'insurance-coverage-start-date': $scope.homeLayout.date === undefined ? "": $scope.homeLayout.date,

                    'insurance-number-occupants': $scope.homeLayout.no_of_occupants === undefined ? "": $scope.homeLayout.no_of_occupants,
                    'insurance-number-animals': $scope.homeLayout.no_of_animals === undefined ? "0": $scope.homeLayout.no_of_animals,
                    'address': {
                        'address1': $scope.homeLayout.street_add1 === undefined ? "": $scope.homeLayout.street_add1,
                        'address2': $scope.homeLayout.street_add2 === undefined ? "": $scope.homeLayout.street_add2,
                        'city': $scope.homeLayout.city === undefined ? "": $scope.homeLayout.city,
                        'state': $scope.homeLayout.state === undefined ? "": $scope.homeLayout.state,
                        'zip': $scope.homeLayout.zip === undefined ? "": $scope.homeLayout.zip
                    }
                };
                data[policyOptionWithBoolean] = $scope.coverage.checkStatus  === undefined ? "false": $scope.coverage.checkStatus;
                data[policyOptionWithSelect] = $scope.coverage.value;

                if ($scope.siteName === 'ses') {
                    var masterPolicy = 'insurance-master-policy';
                    var clientId = 'insurance-client';
                    data[masterPolicy] = $scope.masterPolicy;
                    data[clientId] = $scope.homeLayout.clientId;
                }

                for (i = 0; i < $scope.optionalProductOption.length; i++) {
                    data[$scope.optionalProductOption[i].key] = $scope.optionalProductOption[i].value;
                }

                $http({
                    method: 'POST',
                    url: '/cart/enhanced/'+$scope.productId+'?categoryId='+$scope.categoryId+'&customerId='+customerId,
                    headers:{
                        'Content-Type':'application/json'
                    },
                    data:data
                }).then(function (response) {
                    var data = response.data;
                    if (data.error) {
                        $scope.loaderIcon.show = false;
                        var errorMessage = data.errorMessage;
                        $scope.addressError = {
                             street :errorMessage.indexOf('Address1') !=- 1 || errorMessage.indexOf('Address2') !=- 1,
                             city : errorMessage.indexOf('City') !=- 1,
                             state : errorMessage.indexOf('State') !=- 1,
                             zip : errorMessage.indexOf('Zip') !=- 1
                         };

                        $scope.estimateInstance = false;
                        var errorMessage = response.data.errorMessage;
                        $scope.error = {};
                        var dataText = '';
                        var errorSplit = _.remove(errorMessage.split('\n'));

                        for (var j = 0; j <= errorSplit.length; j++) {
                            var error = errorSplit[j];
                            if (!error) {
                                if (j === errorSplit.length) {
                                    return;
                                }
                                continue;
                            }

                            if (error.indexOf('Address1') !=-1) {
                                var validationMsg = '';
                                var msgSplit = error.split('-');
                                for (var i= 0 ; i <msgSplit.length ; i++) {
                                  if(msgSplit[i].indexOf('Suggested')){
                                    validationMsg = msgSplit[i];
                                  }
                                }
                                if (validationMsg.indexOf('Invalid value') !=-1) {
                                    $scope.validation.address_1 = true;
                                } else {
                                    $scope.error.street = validationMsg;
                                }

                            } else if (error.indexOf('Address2') !=-1) {
                                var validationMsg = '';
                                var msgSplit = error.split('-');
                                for(var i= 0 ; i < msgSplit.length ; i++){
                                    if(msgSplit[i].indexOf('Suggested')){
                                        validationMsg = msgSplit[i];
                                    }
                                }
                                if (validationMsg.indexOf('Invalid value') !=-1) {
                                    $scope.validation.aptAddress = true;
                                } else {
                                    $scope.error.apt = validationMsg;
                                }

                            } else if (error.indexOf('City') !=-1) {
                                var validationMsg = '';
                                var msgSplit = error.split('-');
                                for(var i= 0 ; i < msgSplit.length ; i++){
                                    if(msgSplit[i].indexOf('Suggested')){
                                        validationMsg = msgSplit[i];
                                    }
                                }
                                if (validationMsg.indexOf('Invalid value') !=-1) {
                                    $scope.validation.city = true;
                                } else {
                                    $scope.error.city = validationMsg;
                                }
                            } else if (error.indexOf('State') !=-1) {
                                var validationMsg = '';
                                var msgSplit = error.split('-');
                                for (var i= 0 ; i < msgSplit.length ; i++) {
                                    if (msgSplit[i].indexOf('Suggested')) {
                                        validationMsg = msgSplit[i];
                                    }
                                }
                                if (validationMsg.indexOf('Invalid value') !=-1) {
                                    $scope.validation.state = true;
                                } else {
                                    $scope.error.state = validationMsg;
                                }
                            } else if (error.indexOf('Zip') !=-1) {
                                var validationMsg = '';
                                var msgSplit = error.split('-');
                                for (var i= 0 ; i < msgSplit.length ; i++) {
                                    if (msgSplit[i].indexOf('Suggested')) {
                                        validationMsg = msgSplit[i];
                                    }
                                }
                                if (validationMsg.indexOf('Invalid value') !=-1) {
                                    $scope.validation.zip = true;
                                } else {
                                    $scope.error.zip = validationMsg;
                                }
                            }
                        }
                    }
                    $scope.loaderIcon.show = false;
                    $scope.nextTab('three.tpl.html'),
                    $(".tab-two").css("background-color", "#C39C7C");
                    $(".number-two-circle").css("border", "2px solid #CCCCCC");
                    $(".number-two-circle").css("color", "#CCCCCC");
                    $(".number-three-circle").css("border", "2px solid #ED6B00");
                    $(".number-three-circle").css("color", "#ED6B00");
                    $scope.buyItBtn.show = true;
                    $scope.tabTwoActive = true;
                    $scope.nextTab = function (tabUrl) {
                         if(tabUrl === 'two.tpl.html') {
                           $(".tab-one").css("background-color", "#C39C7C");
                           $(".number-one-circle").css("border", "2px solid #CCCCCC");
                           $(".number-one-circle").css("color", "#CCCCCC");
                           $(".tab-two").css("background-color", "#ED6B00");
                           $(".number-two-circle").css("border", "2px solid #ED6B00");
                           $(".number-two-circle").css("color", "#ED6B00");
                           $scope.tabOneActive = true;
                           $scope.isStreetFocused = true;
                           // $scope.tabOne = false;
                         }
                         $scope.currentTab = tabUrl;
                    };
                    // $state.go('place-order');

                }, function (error) {
                    if (error.status !== 404) {
                        $scope.loaderIcon.show = false;
                        return;
                    }

                    customerService.createCart(customerId).then(function (customerId) {
                        addProductToCart(customerId);
                    }, function (error) {

                    });
                });
            }
        }
        if ($scope.siteName === 'ses') {
            if($scope.homeLayout.clientId) {
                $scope.loaderIcon.show = true;
                valuationService.getMasterPolicy($scope.homeLayout.clientId, $scope.siteName, $scope.dynamicTags.productName).then(function (dataValue) {
                    $scope.masterPolicy = dataValue.data.propertyValue;
                    $scope.validation.clientId = false;
                    $(".form-clientId").css("border-bottom", "2px solid #62e69a");
                    clientIdError = false;
                    $scope.updateCart();
                }, function (error) {
                    $scope.validation.clientId = true;
                    $(".form-clientId").css("border-bottom", "2px solid #d83e3b");
                    $scope.loaderIcon.show = false;
                    clientIdError = true;
                });
            } else {
                $scope.onclientIdValidate($scope.homeLayout.clientId);
                return;
            }
        } else {
            $scope.updateCart();
        }

        };
        if($scope.placeOrder.error) {
            nextTab('three.tpl.html'),
            $(".tab-two").css("background-color", "#C39C7C");
            $(".tab-one").css("background-color", "#C39C7C");
            $scope.tabTwoActive = true;
            $scope.tabOneActive = true;
            $scope.buyItBtn.show = true;
            $(".number-one-circle").css("border", "2px solid #CCCCCC");
            $(".number-one-circle").css("color", "#CCCCCC");
            function nextTab(tabUrl) {
                 if(tabUrl === 'two.tpl.html') {
                   $(".tab-one").css("background-color", "#C39C7C");
                   $(".tab-two").css("background-color", "#ED6B00");
                   $scope.tabOneActive = true;
                   $scope.isStreetFocused = true;
                   // $scope.tabOne = false;
                 }
                 $scope.currentTab = tabUrl;
            }
        }
        document.writeOld = document.write;
        document.writelnOld = document.writeln;

        //Getting the element we are rendering too and setting string and custom function
        var placeholder = document.getElementById('sealPlaceholder'),
            sealHtml = '',
            customWriteFnc = function(html) {
                sealHtml += html;
                placeholder.innerHTML = sealHtml;
            };

        //Overwriting document.write and document.writeln with our own function
        document.write = customWriteFnc;
        document.writeln = customWriteFnc;

        //Loading the script after the page has loaded
        setTimeout(function(){
            var head = document.getElementsByTagName('head')[0],
                script = document.createElement('script');
           script.type= 'text/javascript';
           script.src= '//verify.authorize.net/anetseal/seal.js';
           head.appendChild(script);
        }, 500);
}]);
