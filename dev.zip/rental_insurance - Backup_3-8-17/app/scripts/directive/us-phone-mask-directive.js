app.directive('usPhoneMask', function () {
    return {
        restrict: 'A',
        link: function (scope, ele) {
            var element = ele[0];
            element.addEventListener('blur',function(e){
                ele.mask('(000) 000-0000');
            });
            element.addEventListener('focus',function(e){
                ele.mask('0000000000');
            });
        }
    };
});
