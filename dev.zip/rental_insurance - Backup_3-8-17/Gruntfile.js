/*global module:false*/
'use strict';

module.exports = function(grunt) {

    // load-grunt-tasks will automatically load any tasks you have listed in your
    // devDependencies in your project's package.json, provided that the task's
    // package name begins with the grunt- prefix.
    require('load-grunt-tasks')(grunt);

    // display elapsed time of grunt tasks
    require('time-grunt')(grunt);

    // load our utility functions
    var gruntUtils = require('./grunt-utils.js')(grunt);

    // Project configuration. Run initConfig() now so that other tasks can use grunt.config.get()
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'), // read settings from package.json
        bowerlib: 'app/bower_components',
        app: 'app',
        useminPrepare: {
            html: 'dist/index.html',
            options: {
                dest: 'dist',
                flow: {
                    steps: {
                        js:  ['uglifyjs'],          // js: ['concat', 'uglifyjs'],
                        css: ['cssmin']
                    },
                    post: {}
                }
            }
        }
    });

    // load additional task options from the tasks/options folder
    grunt.config.merge(gruntUtils.readTaskOptions('./tasks/options/'));

    // to generate /app/index.html from /app/index.template.html
    grunt.registerTask('app', [
        'preprocess:app',
        'watch'
    ]);

    // real backend, compressed js files, generates /dist folder (production)
    grunt.registerTask('dist', [
        'clean:dist',
        'copy:dist',
        'preprocess:dist',
        'useminPrepare',
        'uglify',
        'usemin'
    ]);

    // generates /dist
    grunt.registerTask('build', [
        'dist'
    ]);

    // the default is to generate the /dist folder
    grunt.registerTask('default', ['build']);

    // load additional tasks from the tasks directory
    grunt.loadTasks('tasks');
};
