'use strict';

module.exports = function(grnt) {

    var grunt = grnt;

    return {
        /* read the various task options from the files in the specified path
         */
        readTaskOptions : function(path) {
            var glob = require('glob');
            var object = {};
            var key;

            glob.sync('*', {cwd: path}).forEach(function(option) {
                key = option.replace(/\.js$/,'');
                object[key] = require(path + option)(grunt);
                grunt.log.writeln('readTaskOptions: loaded config for ' + key);
            });

            return object;
        }
    };
};