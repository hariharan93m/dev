app.controller('RentalEstimateCtrl' ,
    ['$scope',
    '$filter',
     '$http',
     'valuationService',
     '$state',
     'customerService',
     '$window',
     '$location',
      function($scope, $filter, $http, valuationService, $state, customerService, $window, $location) {
        var categoryId,
            productId,
            dollar = false,
            dynamicCategory = {};
        $scope.address = {};
        $scope.error = {};
        $scope.productOptions = {};
        $scope.productOptions.states = [];
        $scope.optionalCoverage = {};
        $scope.liablityInsurance = false;
        $scope.propertyCoverage = {};
        $scope.propertyCoverage.premiumAmnt = "None";
        $scope.optionalCoverage.premiumAmnt = "None";
        $scope.totalAmount.value = "None";
        $scope.loaderIcon = {};
        $scope.isOrdersummary = false;
        $scope.validation = {};
        $scope.currentTab = 'one.tpl.html';
        $scope.isActiveTab1 = true;
        $scope.isActiveTab2 = false;
        $scope.isActiveTab3 = false;

        $scope.isVisitedTab1 = true;
        $scope.isVisitedTab2 = false;
        $scope.isVisitedTab3 = false;

        $scope.queryParamValues = $location.search();
        if(!(_.isEmpty($scope.queryParamValues))) {
            $scope.homeLayout.firstName = ($scope.queryParamValues.firstName ? $scope.queryParamValues.firstName : "").trim();
            $scope.homeLayout.lastName = ($scope.queryParamValues.lastName ? $scope.queryParamValues.lastName : "").trim();
            $scope.homeLayout.date = ($scope.queryParamValues.coverageStartDate ? $scope.queryParamValues.coverageStartDate : "").trim();
            $scope.homeLayout.no_of_occupants = ($scope.queryParamValues.numberOfOccupants ? $scope.queryParamValues.numberOfOccupants : "").trim();
            $scope.homeLayout.no_of_animals = ($scope.queryParamValues.numberOfPets ? $scope.queryParamValues.numberOfPets : "").charAt(0);
            $scope.homeLayout.street_add1 = $scope.queryParamValues.rentalPropertyAddress ? $scope.queryParamValues.rentalPropertyAddress : "";
            $scope.homeLayout.street_add2 = $scope.queryParamValues.address2 ? $scope.queryParamValues.address2 : "";
            $scope.homeLayout.city = $scope.queryParamValues.city ? $scope.queryParamValues.city : "";
            $scope.homeLayout.zip = ($scope.queryParamValues.zip ? $scope.queryParamValues.zip : "").trim();
            $scope.homeLayout.email = ($scope.queryParamValues.email ? $scope.queryParamValues.email : "").trim();
        }

        $scope.setStateValue = function() {
            if($scope.queryParamValues.state){
                var state = $scope.queryParamValues.state ? $scope.queryParamValues.state : "";
                $scope.homeLayout.state = state.trim();
            }
        };

        customerService.getDynamicProduct().then(function (response) {

            dynamicCategory.name = response.data.categoryName;
            $scope.dynamicTags.productName = response.data.productName;
            dynamicCategory.policyOptionWithBoolean = response.data.policyOptionWithBoolean;
            var poSplit = dynamicCategory.policyOptionWithBoolean.split('.');
            $scope.policyOptionWithBoolean.value = poSplit[1];

            dynamicCategory.policyOptionWithSelect = response.data.policyOptionWithSelect;
            var poSplit = dynamicCategory.policyOptionWithSelect.split('.');
            $scope.policyOptionWithSelect.value = poSplit[1];

            $scope.optionalProductOption = response.data.optionalProductOption;

            $scope.dynamicTags.mainHeader = response.data.mainHeader;
            $window.document.title = "Purchase " +response.data.mainHeader;
            $scope.dynamicTags.bottomNote = response.data.bottomNote;
            $scope.dynamicTags.descriptionOne = response.data.descriptionOne;
            $scope.dynamicTags.descriptionTwo = response.data.descriptionTwo;
            $scope.dynamicTags.faqLink = response.data.faqLink;
            $scope.dynamicTags.faqName = response.data.faqName;
            $scope.dynamicTags.headerTwo = response.data.headerTwo;
            $scope.dynamicTags.howMuchPopUp = response.data.howMuchPopUp;
            $scope.dynamicTags.offeredBy = response.data.offeredBy;
            $scope.dynamicTags.siteUrl = response.data.siteUrl;
            $scope.dynamicTags.whatDoesPopup = response.data.whatDoesPopup;
            $scope.dynamicTags.mandatoryCoverageHeader = response.data.mandatoryCoverageHeader;
            $scope.dynamicTags.optionalCoverageHeader = response.data.optionalCoverageHeader;
            $scope.dynamicTags.termsOfUse = response.data.termsOfUse;
            $scope.dynamicTags.privacyPolicy = response.data.privacyPolicy;
            $scope.dynamicTags.contactNumber = response.data.contactNumber;
            $scope.dynamicTags.contactAddress = response.data.contactAddress;
            $scope.dynamicTags.faqText = response.data.faqText;
            $scope.dynamicTags.tagLine = response.data.tagLine;
            $scope.dynamicTags.clientIdText = response.data.clientIdText;
            $scope.dynamicTags.gtmId = response.data.gtmId;
            $scope.dynamicTags.gaId = response.data.gaId;

            var host = $location.host();
            if (host.indexOf('ses') === 0){
                $scope.siteName = 'ses';
                $scope.siteIdentifier.value = 'ses';
            } else {
                $scope.siteIdentifier.value = 'rhss';
            }
            gtmId = $scope.dynamicTags.gtmId;
            gaId =  $scope.dynamicTags.gaId;
            $('head').append('<script type="text/javascript" src="assets/js/gtm.js"></script>');
            $('head').append('<script type="text/javascript" src="assets/js/ga.js"></script>');
        });

        getParentCategories();
           $scope.currentTab = 'one.tpl.html';
           $scope.isActiveTab1 = true;    // default tab 'select-options'

           $scope.occupants = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];

          $scope.onValidateField = function(field) {
            var regex;
            switch (field) {
              case "first-name":
                regex = new RegExp("^[a-zA-Z ]*$");
                validateField(".form-first-name", $scope.homeLayout.firstName, regex, $scope.requiredPoType["first-name"], "firstName");
                break;
              case "last-name":
                regex = new RegExp("^[a-zA-Z ]*$");
                validateField(".form-last-name", $scope.homeLayout.lastName, regex, $scope.requiredPoType["last-name"], "lastName");
                break;
              case "address":
                regex = new RegExp("^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$");
                validateField(".address-1", $scope.homeLayout.street_add1, regex, $scope.requiredPoType["address"], "street");
                break;
              case "unit":
                regex = new RegExp("^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$");
                validateField(".address-2", $scope.homeLayout.street_add2, regex, false , "apt");
                break;
              case "city":
                regex = new RegExp("^[a-zA-Z ]*$");
                validateField(".form-city", $scope.homeLayout.city, regex, true , "city");
                break;
              case "zip":
                regex = new RegExp("^[0-9]{5}$");
                validateField(".form-zip", $scope.homeLayout.zip, regex, true , "zip");
                break;
              case "email":
                regex = new RegExp("^[a-zA-Z0-9._%+-]+@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$");
                validateField(".form-email", $scope.homeLayout.email, regex, $scope.requiredPoType['email'] , "email");
                break;
              case "insurance-number-occupants":
                regex = new RegExp("^[0-9]*$");
                validateField(".form-occupants", $scope.homeLayout.no_of_occupants, regex, $scope.requiredPoType['insurance-number-occupants'] , "occupantCount");
                break;
              case "insurance-number-animals":
                regex = new RegExp("^[0-9]\d*$");
                var isMandatory = $scope.policyOptionWithBoolean.value === 'insurance-dog-bite-coverage';
                validateField(".form-animals", $scope.homeLayout.no_of_animals, regex, isMandatory , "animalCount");
                break;
            }
          };

          function validateField(fieldId, value, regex, isMandatory, booleanName) {
            if (value && value.length > 0) {
                  $scope.validation[booleanName] = true;
                  if (regex.test(value)) {
                    $scope.validation[booleanName] = false;
                  } else {
                    // $(fieldId).css("border-bottom", "2px solid #d83e3b");
                  }
            } else {
              if (isMandatory) {
                $scope.validation[booleanName] = true;
              } else {
                $scope.validation[booleanName] = null;
                // delete $scope.validation[booleanName];
              }
            }
          }

           $scope.onStateChange = function(value) {
             if(value) {
               if(value.length > 0) {
                   $scope.validation.state = true;
                   $(".form-state").css("border-bottom", "2px solid #62e69a");
                   $scope.validation.state = false;
               }
              } else {
               $(".form-state").css("border-bottom", "2px solid #d83e3b");
                $scope.validation.state = true;
             }
           };

           $scope.onDateValidate = function(val) {
               $scope.validation.date = false;
               setTimeout(function(){
                 if($scope.homeLayout.date) {
                   $(".form-date").css("border-bottom", "2px solid #62e69a");
                 }
               }, 1000);

           };

           $scope.onClickTab = function (tabUrl) {
             if(tabUrl === 'one.tpl.html') {
                  $scope.currentTab = 'one.tpl.html';
                  $scope.isActiveTab1 = true;
                  $scope.isActiveTab2 = false;
                  $scope.isActiveTab3 = false;
                  $scope.buyItBtn.show = false;
             } else if(tabUrl === 'two.tpl.html' && !$scope.isActiveTab1) {
                  $scope.currentTab = 'two.tpl.html';
                  $scope.isVisitedTab2 = true;
                  $scope.isActiveTab1 = false;
                  $scope.isActiveTab2 = true;
                  $scope.isActiveTab3 = false;
                  $scope.buyItBtn.show = false;
            }
           };

           $scope.nextTab = function (tabUrl) {
                if (tabUrl === "three.tpl.html") {
                  $scope.currentTab = tabUrl;
                  $scope.isVisitedTab3 = true;
                  $scope.isActiveTab1 = false;
                  $scope.isActiveTab2 = false;
                  $scope.isActiveTab3 = true;
                  $scope.isStreetFocused = true;
                  $scope.buyItBtn.show = true;
                } else {
                  $scope.isActiveTab1 = false;
                  $scope.onClickTab(tabUrl);
                }
           };

           $scope.propertyCoverage.checkStatus = false;

           $scope.checkPersonalCoverage = function() {
               if (!$scope.propertyCoverage.checkStatus) {
                   $scope.propertyCoverage.checkStatus = true;
               } else {
                   if($scope.propertyCoverage.premiumAmnt !== "None")
                   $scope.totalAmount.value = parseFloat($scope.totalAmount.value) - parseFloat($scope.propertyCoverage.premiumAmnt);
                   $scope.propertyCoverage.checkStatus = false;
                   $scope.propertyCoverage.premiumAmnt = "None";
                   $scope.propertyCoverage.insuredAmnt = null;
               }
           };

           $scope.buyIt = function() {
             $scope.$broadcast ('buyEvent');
           };

           $scope.addToOrderSummary = function() {
              if (!$scope.liablityInsurance) {
                  $scope.liablityInsurance = true;
                  $scope.propertyCoverage.insuredAmnt = null;
                  dollar = true;
              } else {
                $scope.liablityInsurance = false;
                $scope.propertyCoverage.premiumAmnt = "None";
                dollar = false;
                $scope.totalAmount.value = "None";
                $scope.decTwo = false;
              }
           };

            $scope.removeCartValues = function(val, personalProperty) {
                if(personalProperty) {
                    $scope.propertyCoverage.premiumAmnt = "None";
                    $scope.propertyCoverage.insuredAmnt = null;
                    $scope.propertyCoverage.checkStatus = false;
                    dollar = false;
                } else {
                    $scope.optionalCoverage.premiumAmnt = "None";
                    $scope.optionalCoverage.checkStatus = false;
                    $scope.validation.animalCount = false;
                    $scope.homeLayout.no_of_animals = undefined;
                }
                $scope.totalAmount.value = $scope.totalAmount.value - parseFloat(val);
                if ($scope.totalAmount.value % 1 != 0) {
                    $scope.decTwo = false;
                } else {
                    $scope.decTwo = true;
                }
            };

           $scope.newPersonalCoverage = function(val) {
                if($scope.propertyCoverage.premiumAmnt !== "None") {
                   $scope.totalAmount.value = $scope.totalAmount.value - parseFloat($scope.propertyCoverage.premiumAmnt);
                }
                var index = $scope.propertyCoverageValues.indexOf(val);
                $scope.propertyCoverage.premiumAmnt = $scope.annualPremium[index];
                $scope.propertyCoverage.insuredAmnt = val;
                dollar = true;
                $scope.totalAmount.value = parseFloat($scope.totalAmount.value) + parseFloat($scope.propertyCoverage.premiumAmnt);
                if($scope.totalAmount.value % 1 != 0) {
                    $scope.decTwo = false;
                } else {
                    $scope.decTwo = true;
                }
            };

            // invoked when Bodily-Injury-Coverage or Dog-Bite-Coverage checkbox is checked.
            $scope.onOptionalInsuranceChecked = function(val, isApply) {
                if(isApply) {
                    $scope.totalAmount.value = parseFloat($scope.totalAmount.value) + parseFloat(val);
                    if($scope.totalAmount.value % 1 != 0) {
                        $scope.decTwo = false;
                    } else {
                        $scope.decTwo = true;
                    }
                    $scope.optionalCoverage.premiumAmnt = val;
                } else {
                    $scope.removeCartValues(val);
                }
            };

            var clientIdError = false;

            $scope.onclientIdValidate = function(val) {
                if(clientIdError) {
                    return;
                }
                if(!val) {
                    $scope.validation.clientId = true;
                    $(".form-clientId").css("border-bottom", "2px solid #d83e3b");
                    return;
                } else {
                    $scope.validation.clientId = false;
                    $(".form-clientId").css("border-bottom", "2px solid #62e69a");
                }
            };

            //Mobile toggle order summary section
            $scope.toggleOrderSummary = function () {
                if($scope.isOrdersummary) {
                    $scope.isOrdersummary = false;
                } else {
                    $scope.isOrdersummary = true;
                }
            };
        function getParentCategories() {
            valuationService.getParentCategoryValues().then(function (dataValue) {
                var category = _.find(dataValue.data.category, {name: dynamicCategory.name });
                categoryId = category.id;
                $scope.categoryId = categoryId;
                valuationService.productValues(categoryId).then(function (dataValue) {
                    var product = dataValue.data;
                    var stateValue = [];
                    var coverageValue = [];
                    var annualPremium = [];
                    var product = _.find(dataValue.data.product, {name: $scope.dynamicTags.productName });
                    $scope.productName = product.name;
                    var freeValuation = _.each(product.productOption, function(allowedValue){});
                    $scope.retailPrice = product.retailPrice.amount;
                    if ($scope.totalAmount.value === "None") {
                        $scope.totalAmount.value = $scope.retailPrice;
                    }
                    var productaddress = _.find(freeValuation,{attributeName: 'productOption.address'});
                    var allowedValue = _.each(productaddress.allowedValue, function(allowedValue){
                        stateValue.push(allowedValue.attributeValue);
                    });
                    $scope.productOptions.states = stateValue;
                    var personalCoverage = _.find(freeValuation,{attributeName: dynamicCategory.policyOptionWithSelect});
                    var allowedValue = _.each(personalCoverage.allowedValue, function(allowedValue){
                        if (allowedValue.attributeValue !== "None") {
                          coverageValue.push(allowedValue.attributeValue);
                          annualPremium.push(allowedValue.priceAdjustment.amount);
                        }
                    });
                    var coverageAmount = _.find(freeValuation,{attributeName: dynamicCategory.policyOptionWithBoolean});
                    var allowedValue = _.each(coverageAmount.allowedValue, function(allowedValue){
                        if (allowedValue.attributeValue === "false") {
                        //   coverageValue.push(allowedValue.attributeValue);
                          // $scope.amountWithnoPets = allowedValue.priceAdjustment.amount;
                      } else if(allowedValue.attributeValue === "true") {
                          $scope.optionalCoverageValue = allowedValue.priceAdjustment.amount;
                      }
                    });
                    $scope.propertyCoverageValues = coverageValue;
                    $scope.annualPremium = annualPremium;
                    $scope.productId = product.id;
                    $scope.productOptionLabel = getProductOptionLabels(product.productOption);
                    $scope.requiredPoType = requiredPoType(product.productOption);
                });
            }, function (error) {
                $state.go('not-available');
            });
        }

        function getProductOptionLabels(po) {
            var obj = {};
            for (var i = 0; i < po.length; i++) {
                var poSplit = po[i].attributeName.split('.');
                if (poSplit.length > 1) {
                    obj[poSplit[1]] = po[i].label;
                    continue;
                }
                obj[String(i)] = po[i].label;
            }
            return obj;
        }

        function requiredPoType(po) {
            var obj = {};
            for (var i = 0; i < po.length; i++) {
                var poSplit = po[i].attributeName.split('.');
                if (poSplit.length > 1) {
                    obj[poSplit[1]] = po[i].required;
                    continue;
                }
                obj[String(i)] = po[i].required;
            }
            return obj;
        }

        $scope.addToCart = function() {

            $scope.onValidateField("first-name");
            $scope.onValidateField("last-name");
            $scope.onValidateField("address");
            $scope.onValidateField("unit");
            $scope.onValidateField("city");
            $scope.onValidateField("zip");
            $scope.onValidateField("insurance-number-occupants");
            $scope.onValidateField("email");

            $scope.homeLayout.street_add1 === undefined ? "": $scope.homeLayout.street_add1;
            if ($scope.policyOptionWithBoolean.value === 'insurance-dog-bite-coverage'){
                if (!$scope.optionalCoverage.checkStatus){
                    $scope.homeLayout.no_of_animals = undefined;
                } else {
                    $scope.onValidateField("insurance-number-animals");
                }
                if ($scope.optionalCoverage.checkStatus) {
                    if (!$scope.homeLayout.no_of_animals) {
                        $scope.validation.animalCount = true;
                        // $(".form-animals").css("border-bottom", "2px solid #d83e3b");
                        return;
                    }
                    if ($scope.homeLayout.no_of_animals === "0") {
                        $scope.validation.animalCount = true;
                        // $(".form-animals").css("border-bottom", "2px solid #d83e3b");
                        return;
                    }
                }
            } else {
                $scope.onValidateField("insurance-number-animals");
            }

            if (!$scope.homeLayout.email || $scope.validation.email) {
                $scope.validation.email = true;
                return;
            }
            if (!$scope.homeLayout.date || $scope.validation.date) {
                $scope.validation.date = true;
                return;
            }
            if (new Date($scope.homeLayout.date).toString() === "Invalid Date") {
                $scope.validation.date = true;
                $(".form-date").css("border-bottom", "2px solid #d83e3b");
                return;
            }
            if (!$scope.homeLayout.firstName || $scope.validation.firstName) {
                $scope.validation.firstName = true;
                return;
            }
            if (!$scope.homeLayout.lastName || $scope.validation.lastName) {
                $scope.validation.lastName = true;
                return;
            }
            if ($scope.validation.occupantCount) {
                return;
            }
            if ($scope.validation.animalCount) {
                return;
            }

            function updateCart() {

            $scope.validation.email = false;
            $scope.validation.date = false;
            $scope.addressError = {};
            $scope.loaderIcon.show = true;

            $scope.homeLayout.date = $filter('date')($scope.homeLayout.date, "MM/dd/yyyy");
            customerService.getCustomerId({
                'firstName'      : $scope.homeLayout.firstName,
                'lastName'       : $scope.homeLayout.lastName,
                'emailAddress'   : $scope.homeLayout.email,
            }).then(function (customerId) {
              customerService.getCart(customerId).then(function (response) {
                    $scope.cartObject = response.data;
                    if ($scope.cartObject.orderItem) {
                      var orderItemId = $scope.cartObject.orderItem[0].id;
                        // if no cart items found move to root
                        customerService.deletCartItem(customerId, orderItemId).then(function (response) {
                            addProductToCart(customerId);
                            $scope.custId = customerId;
                        }, function (error) {

                        });
                    } else {
                      addProductToCart(customerId);
                      $scope.custId = customerId;
                    }

                }, function (error) {
                  $scope.custId = customerId;
                  addProductToCart(customerId);
                });

            }, function (error) {
                // $scope.loaderIcon.show = false;
            });
            function addProductToCart(customerId) {
                if (!customerId) {
                    return;
                }
                if($scope.propertyCoverage.insuredAmnt === null || $scope.propertyCoverage.insuredAmnt === undefined || $scope.propertyCoverage.insuredAmnt === "" ) {
                    $scope.propertyCoverage.insuredAmnt = "None";
                }

                var policyOptionWithBoolean = $scope.policyOptionWithBoolean.value;
                var policyOptionWithSelect = $scope.policyOptionWithSelect.value;

                var data = {
                    'first-name': $scope.homeLayout.firstName === undefined ? "": $scope.homeLayout.firstName,
                    'last-name': $scope.homeLayout.lastName === undefined ? "": $scope.homeLayout.lastName,
                    'email': $scope.homeLayout.email === undefined ? "": $scope.homeLayout.email,
                    'insurance-coverage-start-date': $scope.homeLayout.date === undefined ? "": $scope.homeLayout.date,

                    'insurance-number-occupants': $scope.homeLayout.no_of_occupants === undefined ? "": $scope.homeLayout.no_of_occupants,
                    'insurance-number-animals': $scope.homeLayout.no_of_animals === undefined ? "0": $scope.homeLayout.no_of_animals,
                    'address': {
                        'address1': $scope.homeLayout.street_add1 === undefined ? "": $scope.homeLayout.street_add1,
                        'address2': $scope.homeLayout.street_add2 === undefined ? "": $scope.homeLayout.street_add2,
                        'city': $scope.homeLayout.city === undefined ? "": $scope.homeLayout.city,
                        'state': $scope.homeLayout.state === undefined ? "": $scope.homeLayout.state,
                        'zip': $scope.homeLayout.zip === undefined ? "": $scope.homeLayout.zip
                    }
                };
                data[policyOptionWithBoolean] = $scope.optionalCoverage.checkStatus  === undefined ? "false": $scope.optionalCoverage.checkStatus;
                data[policyOptionWithSelect] = $scope.propertyCoverage.insuredAmnt;

                if ($scope.siteName === 'ses') {
                    var masterPolicy = 'insurance-master-policy';
                    var clientId = 'insurance-client';
                    data[masterPolicy] = $scope.masterPolicy;
                    data[clientId] = $scope.homeLayout.clientId;
                }

                for (i = 0; i < $scope.optionalProductOption.length; i++) {
                    data[$scope.optionalProductOption[i].key] = $scope.optionalProductOption[i].value;
                }

                $http({
                    method: 'POST',
                    url: '/cart/enhanced/'+$scope.productId+'?categoryId='+$scope.categoryId+'&customerId='+customerId,
                    headers:{
                        'Content-Type':'application/json'
                    },
                    data:data
                }).then(function (response) {
                    var data = response.data;
                    if (data.error) {
                        $scope.loaderIcon.show = false;
                        var errorMessage = data.errorMessage;
                        $scope.addressError = {
                             //show only street error if error is in both address1 and address2
                             address1 :errorMessage.indexOf('Address1') !=- 1 && errorMessage.indexOf('Address2') !=- 1,
                             // error in address one alone
                             address1: errorMessage.indexOf('Address1') !=- 1,
                             city : errorMessage.indexOf('City') !=- 1,
                             state : errorMessage.indexOf('State') !=- 1,
                             zip : errorMessage.indexOf('Zip') !=- 1,
                             // error in address2 alone and no error in address1
                             address2: errorMessage.indexOf('Address2') !=-1 && errorMessage.indexOf('Address1') === -1
                         };

                        $scope.estimateInstance = false;
                        var errorMessage = response.data.errorMessage;
                        $scope.error = {};
                        var dataText = '';
                        var errorSplit = _.remove(errorMessage.split('\n'));

                        for (var j = 0; j <= errorSplit.length; j++) {
                            var error = errorSplit[j];
                            if (!error) {
                                if (j === errorSplit.length) {
                                    return;
                                }
                                continue;
                            }
                            var fields = ["Address1", "Address2", "City", "State", "Zip"];
                            var fieldBoolean = ["street","apt","city","","zip"];
                            for (i = 0; i <fields.length; i++) {
                              if (error.indexOf(fields[i]) !=-1) {
                                  var validationMsg = '';
                                  var msgSplit = error.split('-');
                                  for (var i= 0 ; i <msgSplit.length ; i++) {
                                    if(msgSplit[i].indexOf('Suggested') != -1){
                                      validationMsg = msgSplit[i];
                                    }
                                  }
                                  if (!validationMsg || validationMsg.indexOf('Invalid value') != -1) {
                                      var index = fields.indexOf(fields[i]);
                                      $scope.validation[fieldBoolean[index]] = true;
                                      $scope.addressError[fields[i].toLowerCase()] = false;
                                  } else {
                                      $scope.error[fields[i].toLowerCase()] = validationMsg;
                                  }
                                  break;
                              }
                            }
                        }
                    }
                    $scope.loaderIcon.show = false;
                    $scope.nextTab('three.tpl.html');
                    $scope.buyItBtn.show = true;
                    $scope.tabTwoActive = true;

                    // $state.go('place-order');

                }, function (error) {
                    if (error.status !== 404) {
                        $scope.loaderIcon.show = false;
                        return;
                    }

                    customerService.createCart(customerId).then(function (customerId) {
                        addProductToCart(customerId);
                    }, function (error) {

                    });
                });
            }
        }
        if ($scope.siteName === 'ses') {
            if($scope.homeLayout.clientId) {
                $scope.loaderIcon.show = true;
                valuationService.getMasterPolicy($scope.homeLayout.clientId, $scope.siteName, $scope.dynamicTags.productName).then(function (dataValue) {
                    $scope.masterPolicy = dataValue.data.propertyValue;
                    $scope.validation.clientId = false;
                    $(".form-clientId").css("border-bottom", "2px solid #62e69a");
                    clientIdError = false;
                    updateCart();
                }, function (error) {
                    $scope.validation.clientId = true;
                    $(".form-clientId").css("border-bottom", "2px solid #d83e3b");
                    $scope.loaderIcon.show = false;
                    clientIdError = true;
                });
            } else {
                $scope.onclientIdValidate($scope.homeLayout.clientId);
                return;
            }
        } else {
            updateCart();
        }

        };
        if($scope.placeOrder.error) {
            $scope.nextTab('three.tpl.html');
            $scope.isVisitedTab2 = true;

        }
        document.writeOld = document.write;
        document.writelnOld = document.writeln;

        //Getting the element we are rendering too and setting string and custom function
        var placeholder = document.getElementById('sealPlaceholder'),
            sealHtml = '',
            customWriteFnc = function(html) {
                sealHtml += html;
                placeholder.innerHTML = sealHtml;
            };

        //Overwriting document.write and document.writeln with our own function
        document.write = customWriteFnc;
        document.writeln = customWriteFnc;

        //Loading the script after the page has loaded
        setTimeout(function(){
            var head = document.getElementsByTagName('head')[0],
                script = document.createElement('script');
           script.type= 'text/javascript';
           script.src= '//verify.authorize.net/anetseal/seal.js';
           head.appendChild(script);
        }, 500);
}]);
